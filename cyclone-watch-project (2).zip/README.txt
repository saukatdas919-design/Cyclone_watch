CYCLONE WATCH  -  project files
================================
index.html        Main page: 10-year record, watch, analysis, city weather
livemap.html      NEW  Live Map (Zoom Earth style): satellite, radar, wind, rain,
                  temperature, pressure, storms, timeline, search
css/              style.css (main page), livemap.css (live map)
js/               script.js (main page), livemap.js (live map)
data/history.js   37-storm sample 2016-2025 used by the Live Map
data/Cyclone_Watch_Storm_Dataset_2016-2025.xlsx   Downloadable dataset (linked from index.html)
data/model-forecast.js   Paste your CNN+LSTM model output here (format inside)
images/           Background photos

HOW TO RUN
Unzip, keep the folders as they are, then open index.html (or livemap.html)
in Chrome, Edge or Firefox. No server, VS Code or install is needed.
An internet connection is required for map tiles and live data.

LIVE DATA SOURCES
NASA GIBS (Himawari IR, VIIRS true colour), RainViewer (radar),
Open-Meteo (wind/pressure/temperature/rain + point weather + search),
GDACS (active storms), Esri / OpenStreetMap / CARTO (base maps).
