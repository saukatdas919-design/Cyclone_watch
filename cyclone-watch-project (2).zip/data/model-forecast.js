/* ------------------------------------------------------------------
   MODEL FORECAST HOOK
   Put the output of your CNN+LSTM track/intensity model here and it
   will be drawn on the Live Map (yellow track, time labels, and an
   uncertainty circle at every point).

   Leave "storms" empty to show nothing. Example of one storm:

   window.MODEL_FORECAST = {
     issued: "2026-10-13T06:00:00Z",
     storms: [{
       name: "Low-pressure area 01B",
       track: [
         { h: 0,  lat: 11.2, lon: 88.5, wind_kmh: 45, radius_km: 40 },
         { h: 12, lat: 11.8, lon: 86.4, wind_kmh: 55, radius_km: 51 },
         { h: 24, lat: 12.4, lon: 84.3, wind_kmh: 65, radius_km: 90 }
       ]
     }]
   };
   (radius_km = the model's mean track error at that lead time.)
------------------------------------------------------------------- */
window.MODEL_FORECAST = { issued: null, storms: [] };
