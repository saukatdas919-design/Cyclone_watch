(function(){
'use strict';
var $=function(s,r){return (r||document).querySelector(s)};
var MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
var WD=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

/* [year,name,start,end,basin,cat,wind,pres,place,lat,lon,deaths,flags] flags: ~ approx, > at least, n = no/weak landfall */
var RAW=[
[2016,'Roanu','2016-05-19','2016-05-22','BoB','SCS',100,983,'Chittagong coast, Bangladesh',22.2,91.9,130,'~'],
[2016,'Vardah','2016-12-06','2016-12-13','BoB','VSCS',130,975,'Chennai, Tamil Nadu',13.1,80.3,38,'~'],
[2017,'Mora','2017-05-28','2017-05-31','BoB','SCS',110,978,"Cox's Bazar–Chittagong, Bangladesh",21.9,91.9,10,'~'],
[2017,'Ockhi','2017-11-29','2017-12-06','AS','VSCS',155,976,'Kerala–Lakshadweep, then Surat (weakened)',21.2,72.6,245,'n~'],
[2018,'Sagar','2018-05-16','2018-05-20','AS','CS',65,1000,'Berbera, Somaliland',10.4,45.0,null,''],
[2018,'Mekunu','2018-05-21','2018-05-27','AS','ESCS',175,960,'Salalah, Oman',17.0,54.1,26,''],
[2018,'Luban','2018-10-06','2018-10-15','AS','VSCS',140,976,'Al Mahrah, Yemen',16.2,52.2,14,'~'],
[2018,'Titli','2018-10-08','2018-10-12','BoB','VSCS',150,972,'Gopalpur–Palasa, Odisha–Andhra',18.9,84.6,77,'~'],
[2018,'Gaja','2018-11-10','2018-11-19','BoB','VSCS',125,976,'Vedaranyam, Tamil Nadu',10.4,79.9,45,'~'],
[2018,'Phethai','2018-12-13','2018-12-18','BoB','SCS',100,998,'Katrenikona, Andhra Pradesh',16.3,82.3,8,'~'],
[2019,'Fani','2019-04-30','2019-05-03','BoB','ESCS',215,932,'Puri, Odisha',19.8,85.8,89,''],
[2019,'Vayu','2019-06-10','2019-06-17','AS','VSCS',135,970,'Gujarat coast (no landfall)',20.9,70.4,null,'n'],
[2019,'Hikaa','2019-09-22','2019-09-25','AS','VSCS',140,976,'Duqm, Oman',19.6,57.8,null,''],
[2019,'Kyarr','2019-10-24','2019-11-02','AS','SuCS',250,922,'Near the Oman coast (weakened)',20.5,59.0,null,'n'],
[2019,'Maha','2019-10-30','2019-11-07','AS','ESCS',185,956,'Near the Gujarat coast (weakened)',20.8,70.2,0,'n'],
[2019,'Bulbul','2019-11-05','2019-11-11','BoB','VSCS',135,976,'Sagar Island–Sundarbans',21.7,88.6,40,'~'],
[2020,'Amphan','2020-05-16','2020-05-21','BoB','SuCS',240,925,'Sundarbans, West Bengal–Bangladesh',21.6,88.3,128,'~'],
[2020,'Nisarga','2020-06-01','2020-06-04','AS','SCS',110,984,'Alibag, Maharashtra',18.6,72.9,6,'~'],
[2020,'Gati','2020-11-21','2020-11-24','AS','VSCS',140,984,'Hafun, Somalia',10.4,51.1,null,''],
[2020,'Nivar','2020-11-22','2020-11-27','BoB','VSCS',120,978,'Puducherry–Marakkanam',11.9,79.9,null,''],
[2021,'Tauktae','2021-05-14','2021-05-19','AS','ESCS',195,950,'Una–Diu, Gujarat',20.7,71.0,174,''],
[2021,'Yaas','2021-05-23','2021-05-28','BoB','VSCS',130,970,'Balasore–Dhamra, Odisha',21.2,87.0,null,''],
[2021,'Gulab','2021-09-24','2021-09-28','BoB','CS',85,992,'Kalingapatnam, Andhra–Odisha',18.3,84.1,null,''],
[2021,'Shaheen','2021-09-29','2021-10-04','AS','VSCS',120,984,'Suwayq, Oman',23.8,57.4,13,'~'],
[2022,'Asani','2022-05-07','2022-05-12','BoB','SCS',115,982,'Near the Andhra coast (weakened)',16.3,81.5,null,'n'],
[2022,'Sitrang','2022-10-22','2022-10-25','BoB','CS',85,990,'Barisal, Bangladesh',22.4,90.9,35,'~'],
[2022,'Mandous','2022-12-06','2022-12-10','BoB','SCS',100,992,'Mamallapuram, Tamil Nadu',12.6,80.2,null,''],
[2023,'Mocha','2023-05-09','2023-05-15','BoB','ESCS',215,938,'Sittwe, Myanmar',20.0,93.0,463,''],
[2023,'Biparjoy','2023-06-06','2023-06-19','AS','ESCS',165,958,'Jakhau, Kutch, Gujarat',23.2,68.6,17,''],
[2023,'Michaung','2023-12-01','2023-12-06','BoB','SCS',100,986,'Bapatla, Andhra Pradesh',15.9,80.5,null,''],
[2024,'Remal','2024-05-24','2024-05-28','BoB','SCS',110,979,'Sagar Island–Khepupara',21.8,89.0,85,'~'],
[2024,'Dana','2024-10-21','2024-10-29','BoB','SCS',110,986,'Bhitarkanika–Dhamra, Odisha',20.7,86.9,null,''],
[2024,'Fengal','2024-11-26','2024-12-02','BoB','CS',75,998,'Puducherry–Marakkanam',12.1,79.9,null,''],
[2025,'Shakhti','2025-10-01','2025-10-07','AS','SCS',110,987,'Dissipated near Oman',19.5,58.0,null,'n'],
[2025,'Montha','2025-10-25','2025-10-30','BoB','SCS',95,988,'Narsapur, Andhra Pradesh',16.4,81.7,9,'>'],
[2025,'Senyar','2025-11-25','2025-11-27','BoB','CS',75,999,'Sumatra, Indonesia',4.0,97.8,1200,'>'],
[2025,'Ditwah','2025-11-26','2025-12-03','BoB','CS',75,1000,'Sri Lanka (east coast)',7.9,81.7,640,'>']
];
var CY=RAW.map(function(r,i){return {i:i,y:r[0],n:r[1],s:r[2],e:r[3],b:r[4],c:r[5],w:r[6],p:r[7],loc:r[8],lat:r[9],lon:r[10],d:r[11],f:r[12]}});
var CATS=[
 {k:'CS',n:'Cyclonic Storm',r:'62–88 km/h'},
 {k:'SCS',n:'Severe',r:'89–117'},
 {k:'VSCS',n:'Very Severe',r:'118–165'},
 {k:'ESCS',n:'Extremely Severe',r:'166–221'},
 {k:'SuCS',n:'Super Cyclone',r:'222+'}
];
var CATN={};CATS.forEach(function(c){CATN[c.k]=c});
var BASIN={BoB:'Bay of Bengal',AS:'Arabian Sea'};
var CITIES=[['Kolkata',22.57,88.36],['Dhaka',23.81,90.41],['Chittagong',22.36,91.78],["Cox's Bazar",21.43,91.98],
 ['Bhubaneswar',20.30,85.82],['Puri',19.81,85.83],['Visakhapatnam',17.69,83.22],['Chennai',13.08,80.27],
 ['Port Blair',11.62,92.73],['Colombo',6.93,79.85],['Mumbai',19.08,72.88]];

/* ---------- helpers ---------- */
function fmtD(iso){var p=iso.split('-');return (+p[2])+' '+MON[+p[1]-1]}
function fmtRange(s,e){var a=s.split('-'),b=e.split('-');
  if(a[1]===b[1]&&a[0]===b[0])return (+a[2])+'–'+(+b[2])+' '+MON[+a[1]-1]+' '+a[0];
  return fmtD(s)+' '+a[0]+' – '+fmtD(e)+' '+b[0]}
function fmtDeaths(c){if(c.d==null)return '—';return (c.f.indexOf('>')>-1?'≥':(c.f.indexOf('~')>-1?'~':''))+c.d.toLocaleString('en-IN')}
function clamp(x,a,b){return Math.max(a,Math.min(b,x))}
function median(a){var s=a.slice().sort(function(x,y){return x-y});var m=s.length>>1;return s.length%2?s[m]:(s[m-1]+s[m])/2}
function el(t,c){var e=document.createElement(t);if(c)e.className=c;return e}

var S={view:'bob',year:null,cats:new Set(CATS.map(function(c){return c.k})),sel:null,layers:{up:true,hist:true,live:true},q:'',basin:'',sk:'y',sd:-1,live:null};
var VIEWS={bob:[78,98,5,25],as:[48,78,5,28],all:[42,100,0,32]};

/* ---------- map geometry (lon,lat), hand-drawn simplification ---------- */
var K=12,X0=40,Y0=32;
function px(lon){return (lon-X0)*K}
function py(lat){return (Y0-lat)*K}
function pathOf(a){var d='';for(var i=0;i<a.length;i+=2){d+=(i?'L':'M')+px(a[i]).toFixed(1)+' '+py(a[i+1]).toFixed(1)}return d+'Z'}
var MAIN=[40,-2,41.0,-1.8,41.9,-1.0,42.6,-0.4,43.6,0.8,44.7,1.6,45.3,2.0,46.5,3.4,47.9,4.8,48.8,5.6,49.6,6.8,50.2,8.2,50.8,9.5,51.2,10.4,51.3,11.8,50.3,11.7,49.2,11.3,47.5,11.2,45.0,10.45,43.9,10.9,43.1,11.6,43.3,12.2,43.5,12.7,44.0,12.65,45.0,12.8,46.5,13.4,47.8,13.9,48.5,14.1,49.1,14.5,49.6,14.7,50.8,15.3,52.2,15.7,53.2,16.6,54.1,17.0,55.3,17.4,56.0,17.9,56.9,18.7,57.8,18.95,57.7,19.8,58.6,20.6,58.9,21.4,59.5,22.0,59.8,22.5,59.2,22.9,58.6,23.6,57.8,23.9,56.7,24.4,56.4,25.1,56.3,26.2,56.3,27.1,57.1,26.9,57.77,25.65,60.6,25.3,62.3,25.1,63.5,25.25,64.6,25.2,66.6,25.4,67.0,24.85,67.4,24.0,68.0,23.7,68.3,23.65,68.7,23.2,69.35,22.83,70.2,22.95,70.0,22.6,69.1,22.45,68.95,22.25,69.6,21.65,70.35,20.9,71.0,20.7,72.15,21.75,72.6,22.3,72.6,21.1,72.8,20.4,72.8,19.0,72.9,18.6,73.3,17.0,73.8,15.5,74.1,14.8,74.7,13.3,74.85,12.9,75.35,11.9,75.8,11.25,76.25,9.95,76.3,9.5,76.6,8.9,76.95,8.5,77.55,8.08,78.15,8.8,78.9,9.25,79.3,9.3,79.85,10.3,79.85,10.8,79.77,11.75,79.83,11.93,80.3,13.1,80.3,13.6,80.1,14.45,80.1,15.5,80.5,15.9,81.2,16.15,81.7,16.4,82.3,16.95,83.3,17.7,84.1,18.3,84.9,19.25,85.5,19.6,85.85,19.8,86.7,20.3,86.95,20.75,87.05,21.45,87.55,21.6,88.0,21.75,88.1,21.65,88.9,21.65,89.5,21.75,90.2,22.0,90.7,22.3,91.1,22.5,91.5,22.6,91.8,22.3,91.95,21.45,92.3,20.85,92.9,20.15,93.55,19.4,94.3,18.45,94.55,17.6,94.4,16.2,94.3,15.95,94.9,15.85,95.4,15.9,95.9,16.15,96.2,16.5,96.9,16.9,97.3,16.7,97.65,16.5,97.85,15.25,98.2,14.1,98.6,12.45,98.55,10.0,98.3,8.0,98.4,7.7,99.5,7.4,100.0,6.5,100.35,5.4,100.6,4.2,100.9,3.6,101.3,3.0,102.25,2.2,103.5,1.3,104.1,1.3,104.2,1.6,103.4,2.6,103.4,3.8,103.1,5.3,102.25,6.2,101.8,6.45,100.6,7.2,100.0,8.45,99.3,9.1,99.2,10.5,99.8,11.8,100.05,12.6,100.5,13.4,101.0,13.1,101.6,12.65,102.6,12.0,103.6,10.6,105,10.4,105,32,40,32];
var GULF=[56.6,26.3,56.3,26.2,56.1,25.8,55.3,25.3,54.4,24.5,52.5,24.2,51.6,24.6,51.3,26.1,50.6,26.2,50.1,26.4,49.7,27.0,48.8,28.0,48.3,29.1,47.8,29.9,48.5,30.3,49.2,30.4,50.0,30.0,50.2,29.5,50.8,28.9,51.6,27.9,52.6,27.5,54.0,26.8,54.9,26.55,56.3,27.1,56.6,27.0];
var REDSEA=[43.3,12.7,43.2,13.3,42.9,14.8,42.6,16.9,41.5,19.0,40.7,20.5,39.2,21.5,38.5,23.5,37.2,25.5,35.5,28.0,34.0,29.5,33.0,30.0,33.5,28.0,33.8,27.2,34.9,25.1,35.8,23.9,36.7,22.0,37.2,19.6,38.5,17.5,39.5,15.7,40.8,14.9,41.8,14.0,42.7,13.0];
var ISLES=[
 [79.85,9.8,80.25,9.8,80.9,9.4,81.4,9.3,81.25,8.55,81.7,7.7,81.85,7.0,81.1,6.1,80.6,5.9,80.2,6.0,79.85,6.9,79.8,8.0,79.9,8.9],
 [92.85,13.5,93.05,13.4,93.1,12.5,93.0,11.5,92.7,11.5,92.7,12.3,92.75,13.0],
 [93.6,7.35,93.95,7.2,93.9,6.8,93.7,6.8],
 [92.7,9.25,92.82,9.2,92.75,9.1],
 [53.3,12.65,54.5,12.55,54.0,12.3,53.4,12.3],
 [95.3,5.6,96.4,5.25,97.1,5.2,98.0,4.5,98.7,3.7,99.7,2.9,100.8,2.1,101.45,1.7,102.2,1.0,103.1,0.6,104,-0.2,106,-0.4,106,-3,100.8,-3,100.35,-0.95,99.1,0.3,98.8,1.7,97.5,2.5,96.5,3.8,95.9,4.8]
];
var LAND=pathOf(MAIN)+ISLES.map(pathOf).join('');
var WATER=pathOf(GULF)+pathOf(REDSEA);
var SEAL=[['Bay of Bengal',89,15.5,['bob','all']],['Arabian Sea',64.5,15,['as','all']],['Andaman Sea',95.8,11.2,['bob','all']],['Indian Ocean',68,2.5,['as','all']],['Indian Ocean',84,6.2,['bob']]];
var CTYL=[['India',79.5,22.5,['bob','as','all']],['Bangladesh',90.2,24.3,['bob','all']],['Myanmar',95.8,21.5,['bob','all']],['Pakistan',68,28,['as','all']],['Iran',56,29.5,['as','all']],['Oman',56.5,20.5,['as','all']],['Yemen',46.5,15.8,['as','all']],['Somalia',46,7.5,['as','all']],['Sri Lanka',80.7,7.5,['bob']],['Thailand',99.2,17,['all']]];

/* upcoming corridor (indicative, built only from IMD's stated direction) */
var TRK=[[92.5,10.5],[88.5,11.2],[84.8,12.0],[81.6,13.0],[80.3,13.4]];
var HW=[0.8,1.4,2.0,2.6,3.0];
function corridor(){
  var L=[],R=[];
  for(var i=0;i<TRK.length;i++){
    var a=TRK[Math.max(0,i-1)],b=TRK[Math.min(TRK.length-1,i+1)];
    var dx=b[0]-a[0],dy=b[1]-a[1],n=Math.hypot(dx,dy)||1,nx=-dy/n,ny=dx/n;
    L.push(TRK[i][0]+nx*HW[i],TRK[i][1]+ny*HW[i]);
    R.unshift(TRK[i][0]-nx*HW[i],TRK[i][1]-ny*HW[i]);
  }
  var out=L.slice();for(var j=0;j<R.length;j+=2)out.push(R[j],R[j+1]);
  return out;
}
var COR=corridor();
var UPPTS=[{n:1,lon:94.3,lat:12.9,t:'11 Oct: possible upper-air cyclonic circulation, north Andaman Sea'},
 {n:2,lon:92.5,lat:10.5,t:'13 Oct: possible low-pressure area, south-east Bay of Bengal (position approximate)'},
 {n:3,lon:80.3,lat:13.4,t:'16–17 Oct: towards north Tamil Nadu–south Andhra coast (possible)'}];

/* ---------- tooltip ---------- */
var tip=$('#tip');
document.addEventListener('pointermove',function(e){
  var t=e.target.closest&&e.target.closest('[data-tip]');
  if(!t){tip.style.display='none';return}
  tip.textContent=t.getAttribute('data-tip');tip.style.display='block';
  var x=Math.min(e.clientX+12,window.innerWidth-tip.offsetWidth-8),y=e.clientY+14;
  if(y+tip.offsetHeight>window.innerHeight-6)y=e.clientY-tip.offsetHeight-10;
  tip.style.left=Math.max(6,x)+'px';tip.style.top=y+'px';
});
document.addEventListener('pointerdown',function(e){if(!(e.target.closest&&e.target.closest('[data-tip]')))tip.style.display='none'});

/* ---------- map ---------- */
var mapBox=$('#mapBox');
function visible(c){return (S.year==null||c.y===S.year)&&S.cats.has(c.c)}
function renderMap(){
  var v=VIEWS[S.view],vbW=(v[1]-v[0])*K,vbH=(v[3]-v[2])*K,vx=(v[0]-X0)*K,vy=(Y0-v[3])*K;
  mapBox.style.aspectRatio=vbW+' / '+vbH;
  var s=(mapBox.clientWidth||360)/vbW;
  var u=function(n){return +(n/s).toFixed(2)};
  var h='<svg viewBox="'+vx+' '+vy+' '+vbW+' '+vbH+'" role="img" aria-label="Map of the north Indian Ocean">';
  h+='<rect class="ocean" x="'+(vx-500)+'" y="'+(vy-500)+'" width="'+(vbW+1000)+'" height="'+(vbH+1000)+'"/>';
  h+='<path class="land" d="'+LAND+'" style="stroke-width:'+u(.9)+'px"/>';
  h+='<path class="land" d="'+WATER+'" style="fill:var(--ocean);stroke-width:'+u(.9)+'px"/>';
  var st=(v[1]-v[0])>40?10:5,i;
  for(i=Math.ceil(v[0]/st)*st;i<=v[1];i+=st){
    h+='<line class="grat" x1="'+px(i)+'" y1="'+vy+'" x2="'+px(i)+'" y2="'+(vy+vbH)+'" style="stroke-width:'+u(.8)+'px"/>';
    h+='<text class="gl" x="'+(px(i)+u(3))+'" y="'+(vy+u(11))+'" style="font-size:'+u(10)+'px">'+i+'°E</text>';
  }
  for(i=Math.ceil(v[2]/st)*st;i<=v[3];i+=st){
    h+='<line class="grat" x1="'+vx+'" y1="'+py(i)+'" x2="'+(vx+vbW)+'" y2="'+py(i)+'" style="stroke-width:'+u(.8)+'px"/>';
    h+='<text class="gl" x="'+(vx+u(4))+'" y="'+(py(i)-u(3))+'" style="font-size:'+u(10)+'px">'+i+'°N</text>';
  }
  SEAL.forEach(function(l){if(l[3].indexOf(S.view)>-1)h+='<text class="sea" x="'+px(l[1])+'" y="'+py(l[2])+'" text-anchor="middle" style="font-size:'+u(S.view==='all'?12:14)+'px">'+l[0]+'</text>'});
  CTYL.forEach(function(l){if(l[3].indexOf(S.view)>-1)h+='<text class="cty" x="'+px(l[1])+'" y="'+py(l[2])+'" text-anchor="middle" style="font-size:'+u(11)+'px">'+l[0]+'</text>'});
  if(S.layers.live&&S.live){
    S.live.forEach(function(c){
      if(c.lon<v[0]-1||c.lon>v[1]+1||c.lat<v[2]-1||c.lat>v[3]+1)return;
      h+='<circle class="cell" cx="'+px(c.lon)+'" cy="'+py(c.lat)+'" r="'+u(16)+'" fill-opacity="'+(0.08+c.score/100*0.5).toFixed(2)+'" data-tip="'+c.lat+'°N '+c.lon+'°E: risk score '+c.score+', min pressure '+c.minP.toFixed(0)+' hPa"/>';
    });
  }
  if(S.layers.up){
    h+='<path class="cor" d="'+pathOf(COR)+'" style="stroke-width:'+u(1.3)+'px;stroke-dasharray:'+u(6)+' '+u(5)+'"/>';
    h+='<polyline class="trk" points="'+px(UPPTS[0].lon)+','+py(UPPTS[0].lat)+' '+TRK.map(function(p){return px(p[0])+','+py(p[1])}).join(' ')+'" style="stroke-width:'+u(2)+'px;stroke-dasharray:'+u(2)+' '+u(6)+'"/>';
    h+='<line class="zone" x1="'+px(79.9)+'" y1="'+py(11.6)+'" x2="'+px(80.3)+'" y2="'+py(15.6)+'" style="stroke-width:'+u(9)+'px"/>';
    UPPTS.forEach(function(p){
      h+='<g class="pt" data-tip="'+p.t+'"><circle cx="'+px(p.lon)+'" cy="'+py(p.lat)+'" r="'+u(9)+'" style="stroke-width:'+u(1.5)+'px"/><text x="'+px(p.lon)+'" y="'+(py(p.lat)+u(4))+'" style="font-size:'+u(11)+'px">'+p.n+'</text></g>';
    });
  }
  if(S.layers.hist){
    CY.filter(visible).sort(function(a,b){return b.w-a.w}).forEach(function(c){
      var r=4+(c.w-60)/30;
      var tt=c.n+' ('+c.y+') · '+CATN[c.c].n+' · '+c.w+' km/h';
      h+='<g class="mk'+(c.f.indexOf('n')>-1?' nl':'')+'" data-i="'+c.i+'" tabindex="0" role="button" aria-label="'+tt+'" data-tip="'+tt+'">'+
         '<circle class="hit" cx="'+px(c.lon)+'" cy="'+py(c.lat)+'" r="'+u(Math.max(r+3,12))+'"/>'+
         '<circle class="dot" cx="'+px(c.lon)+'" cy="'+py(c.lat)+'" r="'+u(r)+'" style="fill:var(--c-'+c.c+');stroke-width:'+u(1.2)+'px"/></g>';
    });
  }
  if(S.layers.hist&&S.year==null){
    var ax=px(84.1),ay=py(18.3);
    h+='<g class="mk nl" tabindex="0" data-tip="2026: BOB 06 (popularly called Arnab). Deep depression, 55 km/h, crossed near Kalingapatnam on 23–24 Sep. Not an IMD-named cyclone."><circle class="hit" cx="'+ax+'" cy="'+ay+'" r="'+u(14)+'"/><rect x="'+(ax-u(6))+'" y="'+(ay-u(6))+'" width="'+u(12)+'" height="'+u(12)+'" transform="rotate(45 '+ax+' '+ay+')" style="fill:var(--accent);stroke:var(--ink);stroke-width:'+u(1.2)+'px"/><text class="sellab" x="'+(ax+u(10))+'" y="'+(ay-u(8))+'" style="font-size:'+u(11)+'px;stroke-width:'+u(3)+'px">2026 BOB 06</text></g>';
  }
  if(S.sel!=null){
    var c=CY[S.sel],rr=4+(c.w-60)/30;
    h+='<circle class="sel" cx="'+px(c.lon)+'" cy="'+py(c.lat)+'" r="'+u(rr+6)+'" style="stroke-width:'+u(2)+'px"/>';
    h+='<text class="sellab" x="'+(px(c.lon)+u(rr+9))+'" y="'+(py(c.lat)+u(4))+'" style="font-size:'+u(13)+'px;stroke-width:'+u(3)+'px">'+c.n+'</text>';
  }
  mapBox.innerHTML=h+'</svg>';
}
mapBox.addEventListener('click',function(e){var g=e.target.closest('[data-i]');if(g)select(+g.getAttribute('data-i'),false)});
mapBox.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){var g=e.target.closest('[data-i]');if(g){e.preventDefault();select(+g.getAttribute('data-i'),false)}}});

function fitView(c){
  var o=['bob','as','all'];
  for(var i=0;i<o.length;i++){var v=VIEWS[o[i]];if(c.lon>=v[0]&&c.lon<=v[1]&&c.lat>=v[2]&&c.lat<=v[3])return o[i]}
  return 'all';
}
function setView(v){S.view=v;[].forEach.call($('#viewSeg').children,function(b){b.setAttribute('aria-pressed',b.dataset.v===v)});renderMap()}
function select(i,fromTable){
  S.sel=i;var c=CY[i];
  if(fromTable){var v=VIEWS[S.view];if(!(c.lon>=v[0]&&c.lon<=v[1]&&c.lat>=v[2]&&c.lat<=v[3]))setView(fitView(c))}
  renderMap();renderDetail();markRows();
}
function markRows(){[].forEach.call($('#tbl tbody').rows,function(r){r.setAttribute('aria-selected',String(+r.dataset.i===S.sel))})}
function renderDetail(){
  var d=$('#detail');
  if(S.sel==null){
    d.innerHTML='<h3>Select a storm</h3><p class="small muted">Click a circle on the map or a row in the table below to see details here.</p>'+
      '<dl><dt>Total</dt><dd class="mono">'+CY.length+' storms</dd><dt>Bay of Bengal</dt><dd class="mono">'+CY.filter(function(c){return c.b==='BoB'}).length+'</dd><dt>Arabian Sea</dt><dd class="mono">'+CY.filter(function(c){return c.b==='AS'}).length+'</dd></dl>';
    return;
  }
  var c=CY[S.sel];
  d.innerHTML='<div><h3 style="font-size:20px">'+c.n+' <span class="muted mono" style="font-size:14px;font-weight:400">'+c.y+'</span></h3>'+
   '<span class="badge"><span class="sw" style="background:var(--c-'+c.c+')"></span>'+CATN[c.c].n+' ('+c.c+')</span></div>'+
   '<dl><dt>Dates</dt><dd>'+fmtRange(c.s,c.e)+'</dd><dt>Basin</dt><dd>'+BASIN[c.b]+'</dd>'+
   '<dt>Peak wind</dt><dd class="mono">'+c.w+' km/h</dd><dt>Min pressure</dt><dd class="mono">'+c.p+' hPa</dd>'+
   '<dt>Landfall</dt><dd>'+c.loc+'</dd><dt>Deaths</dt><dd class="mono">'+fmtDeaths(c)+'</dd></dl>'+
   '<p class="small muted">Coordinates are an approximate point on the landfall or affected coast. Wind speed is IMD 3-minute sustained.</p>';
}

$('#viewSeg').addEventListener('click',function(e){var b=e.target.closest('button');if(b)setView(b.dataset.v)});
$('#layerSeg').addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;
  var l=b.dataset.l;S.layers[l]=!S.layers[l];b.setAttribute('aria-pressed',S.layers[l]);renderMap()});
(function(){
  var yb=$('#years'),all=el('button');all.type='button';all.textContent='All years';all.setAttribute('aria-pressed','true');all.dataset.y='';yb.appendChild(all);
  for(var y=2016;y<=2025;y++){var b=el('button');b.type='button';b.textContent=y;b.dataset.y=y;b.setAttribute('aria-pressed','false');yb.appendChild(b)}
  yb.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;
    S.year=b.dataset.y?+b.dataset.y:null;[].forEach.call(yb.children,function(x){x.setAttribute('aria-pressed',x===b)});
    if(S.sel!=null&&!visible(CY[S.sel]))S.sel=null;renderMap();renderDetail();renderTable()});
  var lg=$('#legend');
  CATS.forEach(function(c){var b=el('button','lg');b.type='button';b.dataset.k=c.k;b.setAttribute('aria-pressed','true');
    b.innerHTML='<span class="sw" style="background:var(--c-'+c.k+')"></span>'+c.n+' <span class="muted small">'+c.r+'</span>';lg.appendChild(b)});
  lg.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var k=b.dataset.k;
    if(S.cats.has(k)){if(S.cats.size>1)S.cats.delete(k)}else S.cats.add(k);
    [].forEach.call(lg.children,function(x){x.setAttribute('aria-pressed',S.cats.has(x.dataset.k))});
    if(S.sel!=null&&!visible(CY[S.sel]))S.sel=null;renderMap();renderDetail();renderTable()});
})();

/* ---------- table ---------- */
var COLS=[['y','Year',0],['n','Name',0],['s','Dates',0],['b','Basin',0],['c','Intensity',0],['w','Wind (km/h)',1],['p','Pressure (hPa)',1],['loc','Landfall / affected area',0],['d','Deaths',1]];
var CORD={CS:1,SCS:2,VSCS:3,ESCS:4,SuCS:5};
function renderHead(){
  var h='<tr>';COLS.forEach(function(c){
    var on=S.sk===c[0],ar=on?(S.sd>0?' ↑':' ↓'):'';
    h+='<th class="'+(c[2]?'num':'')+'" aria-sort="'+(on?(S.sd>0?'ascending':'descending'):'none')+'"><button type="button" data-k="'+c[0]+'">'+c[1]+ar+'</button></th>';
  });
  $('#tbl thead').innerHTML=h+'</tr>';
}
function renderTable(){
  renderHead();
  var q=S.q.trim().toLowerCase();
  var rows=CY.filter(function(c){
    if(!visible(c))return false;if(S.basin&&c.b!==S.basin)return false;
    if(q&&c.n.toLowerCase().indexOf(q)<0&&c.loc.toLowerCase().indexOf(q)<0)return false;return true});
  var k=S.sk,d=S.sd;
  rows.sort(function(a,b){
    var x=a[k],y=b[k];
    if(k==='c'){x=CORD[a.c];y=CORD[b.c]}
    if(k==='s'){x=a.s;y=b.s}
    if(x==null)x=-1;if(y==null)y=-1;
    if(typeof x==='string')return d*x.localeCompare(y);
    return d*(x-y);
  });
  var h='';
  rows.forEach(function(c){
    h+='<tr data-i="'+c.i+'" tabindex="0" aria-selected="'+(c.i===S.sel)+'"><td class="num" style="text-align:left">'+c.y+'</td><td class="nm">'+c.n+'</td><td>'+fmtRange(c.s,c.e)+'</td><td>'+BASIN[c.b]+'</td>'+
      '<td><span class="badge"><span class="sw" style="background:var(--c-'+c.c+')"></span>'+c.c+'</span></td><td class="num">'+c.w+'</td><td class="num">'+c.p+'</td><td>'+c.loc+'</td><td class="num">'+fmtDeaths(c)+'</td></tr>';
  });
  $('#tbl tbody').innerHTML=h||'<tr><td colspan="9" class="muted">No matches. Try changing the filters.</td></tr>';
  $('#tCount').textContent='Showing '+rows.length+' of 37 storms in sample';
}
$('#tbl').addEventListener('click',function(e){
  var b=e.target.closest('th button');
  if(b){var k=b.dataset.k;if(S.sk===k)S.sd=-S.sd;else{S.sk=k;S.sd=(k==='n'||k==='loc'||k==='b')?1:-1}renderTable();return}
  var r=e.target.closest('tbody tr[data-i]');if(r)select(+r.dataset.i,true);
});
$('#tbl').addEventListener('keydown',function(e){if(e.key==='Enter'){var r=e.target.closest('tbody tr[data-i]');if(r)select(+r.dataset.i,true)}});
$('#search').addEventListener('input',function(e){S.q=e.target.value;renderTable()});
$('#basin').addEventListener('change',function(e){S.basin=e.target.value;renderTable()});

/* ---------- analog analysis ---------- */
var ANALOGS=CY.filter(function(c){var m=+c.s.slice(5,7);return c.b==='BoB'&&m>=10&&c.lat>=10&&c.lat<=17.5&&c.lon>=79&&c.lon<=83});
function renderAnalog(){
  var A=ANALOGS,n=A.length,v=A.filter(function(c){return CORD[c.c]>=3}).length;
  var days=A.map(function(c){return (new Date(c.e)-new Date(c.s))/864e5+1});
  var known=A.filter(function(c){return c.d!=null});
  $('#anStats').innerHTML=
   '<div class="stat"><b>'+n+'</b><span>Matching storms (Oct–Dec, this coast)</span></div>'+
   '<div class="stat"><b>'+median(A.map(function(c){return c.w})).toFixed(0)+'</b><span>Median peak wind, km/h</span></div>'+
   '<div class="stat"><b>'+v+'/'+n+'</b><span>Very Severe (VSCS) or stronger</span></div>'+
   '<div class="stat"><b>'+median(days).toFixed(0)+' days</b><span>Median lifetime, formation to end</span></div>';
  var t=$('#anTags');t.innerHTML='';
  A.slice().sort(function(a,b){return a.s<b.s?1:-1}).forEach(function(c){
    var s=el('span','tag'),b=el('button');b.type='button';b.textContent=c.n+' '+c.y+' · '+c.c;
    b.addEventListener('click',function(){select(c.i,true);$('#mH').scrollIntoView({behavior:'smooth',block:'start'})});
    s.appendChild(b);t.appendChild(s)});
  $('#anNote').textContent='This is what storms of this season on this coast have looked like in the past. History cannot tell whether the upcoming low will become a cyclone or how strong it will be. IMD will say that after looking at sea-surface temperature, wind shear and the exact position of the system.'+
   (known.length?' Known deaths: '+known.map(function(c){return c.n+' '+fmtDeaths(c)}).join(', ')+'.':'');
}

/* ---------- live scan (Open-Meteo; needs the file opened in a normal browser with internet) ---------- */
function setLive(on,msg){var c=$('#liveChip');c.className='chip '+(on?'on':'off');c.querySelector('span').textContent=msg}
function fetchJ(url,ms){
  var ctl=typeof AbortController!=='undefined'?new AbortController():null;
  var to=setTimeout(function(){if(ctl)ctl.abort()},ms||15000);
  return fetch(url,ctl?{signal:ctl.signal}:{}).then(function(r){clearTimeout(to);if(!r.ok)throw new Error('http '+r.status);return r.json()});
}
function gridPts(){
  var p=[],la,lo;
  for(la=6;la<=21;la+=3)for(lo=82;lo<=94;lo+=4)p.push([la,lo]);
  for(la=8;la<=24;la+=4)for(lo=58;lo<=70;lo+=4)p.push([la,lo]);
  return p;
}
function fmtTime(iso){return fmtD(iso.slice(0,10))+', '+iso.slice(11,16)}
function lvlOf(s){return s>=60?['hi','High']:(s>=35?['mid','Medium']:['lo','Low'])}
function runScan(){
  var box=$('#scan');box.className='empty';box.textContent='Fetching model data…';
  var pts=gridPts();
  var url='https://api.open-meteo.com/v1/forecast?latitude='+pts.map(function(p){return p[0]}).join(',')+'&longitude='+pts.map(function(p){return p[1]}).join(',')+
    '&hourly=pressure_msl,wind_speed_10m,wind_gusts_10m&forecast_days=7&wind_speed_unit=kmh&timezone=Asia%2FKolkata';
  return fetchJ(url,20000).then(function(arr){
    if(!Array.isArray(arr))arr=[arr];
    var cells=arr.map(function(o,i){
      var P=o.hourly.pressure_msl,W=o.hourly.wind_speed_10m,T=o.hourly.time,mi=-1,minP=1e9,maxW=0;
      for(var k=0;k<P.length;k++){if(P[k]!=null&&P[k]<minP){minP=P[k];mi=k}if(W[k]!=null&&W[k]>maxW)maxW=W[k]}
      var sP=clamp((1010-minP)/14,0,1),sW=clamp((maxW-25)/45,0,1);
      return {lat:pts[i][0],lon:pts[i][1],minP:minP,maxW:maxW,t:T[mi],score:Math.round(100*(0.6*sP+0.4*sW))};
    });
    S.live=cells;setLive(true,'Live data: on');renderMap();
    var top=cells.slice().sort(function(a,b){return b.score-a.score}).slice(0,3);
    var h='<ul class="risklist">';
    top.forEach(function(c){var l=lvlOf(c.score);
      h+='<li><span class="lvl '+l[0]+'">'+l[1]+'</span><span class="mono">'+c.lat+'°N '+c.lon+'°E</span><span>min pressure <b class="mono">'+c.minP.toFixed(0)+' hPa</b> ('+fmtTime(c.t)+'), peak wind <b class="mono">'+c.maxW.toFixed(0)+' km/h</b></span></li>'});
    h+='</ul><p class="note" style="margin-top:8px">A simple screening of pressure and wind in a global weather model\'s 7-day forecast. Models of this kind tend to underestimate cyclone cores, so this is an early hint, not a warning. On the map, a darker red circle means a higher score.</p>';
    box.className='';box.innerHTML=h;
  }).catch(function(){
    S.live=null;renderMap();setLive(false,'Live data: off');
    box.className='empty';
    box.textContent='Could not fetch live data. Check your internet connection and try again. If this page is inside a restricted preview, open the .html file directly in a browser such as Chrome.';
  });
}
$('#rescan').addEventListener('click',runScan);

/* ---------- city weather ---------- */
function wcode(c){
  if(c===0)return ['sun','Clear sky'];
  if(c<=2)return ['psun','Partly cloudy'];
  if(c===3)return ['cloud','Overcast'];
  if(c===45||c===48)return ['fog','Fog'];
  if(c>=51&&c<=57)return ['rain','Drizzle'];
  if(c>=61&&c<=67)return ['rain','Rain'];
  if(c>=71&&c<=77)return ['cloud','Snow'];
  if(c>=80&&c<=82)return ['rain','Showers'];
  if(c>=95)return ['storm','Thunderstorm'];
  return ['cloud','Overcast'];
}
function ico(k){
  var m={
   sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>',
   psun:'<circle cx="8" cy="8" r="3"/><path d="M8 2v2M2 8h2M3.8 3.8l1.4 1.4M12.2 3.8l-1.4 1.4"/><path d="M8 20h10a4 4 0 0 0 .5-8A5.5 5.5 0 0 0 8 13.5 3.3 3.3 0 0 0 8 20z"/>',
   cloud:'<path d="M6 19h11a4.5 4.5 0 0 0 .6-9A6.5 6.5 0 0 0 5 11.5 3.8 3.8 0 0 0 6 19z"/>',
   rain:'<path d="M6 15h11a4 4 0 0 0 .5-8A6 6 0 0 0 5.5 8.5 3.4 3.4 0 0 0 6 15z"/><path d="M8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
   storm:'<path d="M6 14h11a4 4 0 0 0 .5-8A6 6 0 0 0 5.5 7.5 3.4 3.4 0 0 0 6 14z"/><path d="M12 14l-2.5 4h3L10.5 22"/>',
   fog:'<path d="M5 9h14M3 13h18M6 17h12"/>'};
  return '<svg class="wi" viewBox="0 0 24 24" aria-hidden="true">'+(m[k]||m.cloud)+'</svg>';
}
function wdir(d){return ['north','north-east','east','south-east','south','south-west','west','north-west'][Math.round(d/45)%8]}
var citySel=$('#city');
CITIES.forEach(function(c,i){var o=el('option');o.value=i;o.textContent=c[0];citySel.appendChild(o)});
function loadCity(){
  var c=CITIES[+citySel.value],out=$('#cityOut');out.className='empty';out.textContent='Fetching weather for '+c[0]+'…';
  var url='https://api.open-meteo.com/v1/forecast?latitude='+c[1]+'&longitude='+c[2]+
   '&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl'+
   '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_gusts_10m_max&forecast_days=7&wind_speed_unit=kmh&timezone=auto';
  fetchJ(url,15000).then(function(j){
    var cu=j.current,w=wcode(cu.weather_code),h='';
    h+='<div class="now">'+ico(w[0])+'<div><div class="t">'+Math.round(cu.temperature_2m)+'°</div><div class="small muted">'+w[1]+' · feels like '+Math.round(cu.apparent_temperature)+'°</div></div></div>';
    h+='<div class="metrics"><div><span>Humidity</span><br><b class="mono">'+cu.relative_humidity_2m+'%</b></div>'+
       '<div><span>Wind (from '+wdir(cu.wind_direction_10m)+')</span><br><b class="mono">'+Math.round(cu.wind_speed_10m)+' km/h</b></div>'+
       '<div><span>Sea-level pressure</span><br><b class="mono">'+Math.round(cu.pressure_msl)+' hPa</b></div>'+
       '<div><span>Rain (now)</span><br><b class="mono">'+cu.precipitation+' mm</b></div></div>';
    h+='<div class="days">';
    j.daily.time.forEach(function(t,i){
      var dw=wcode(j.daily.weather_code[i]),dd=new Date(t+'T00:00');
      h+='<div class="day" data-tip="'+dw[1]+', max gust '+Math.round(j.daily.wind_gusts_10m_max[i])+' km/h"><b>'+(i===0?'Today':WD[dd.getDay()])+'</b>'+ico(dw[0])+
        '<span class="mono">'+Math.round(j.daily.temperature_2m_max[i])+'°/'+Math.round(j.daily.temperature_2m_min[i])+'°</span><span class="r">'+(j.daily.precipitation_sum[i]>0?j.daily.precipitation_sum[i].toFixed(0)+' mm':'')+'</span></div>';
    });
    h+='</div><p class="small muted">Data: Open-Meteo. Times are local.</p>';
    out.className='';out.innerHTML=h;setLive(true,'Live data: on');
  }).catch(function(){
    out.className='empty';
    out.textContent='Could not fetch weather data. Check your internet connection and press Refresh. If this page is inside a restricted preview, open the .html file directly in a browser.';
  });
}
citySel.addEventListener('change',loadCity);$('#cityGo').addEventListener('click',loadCity);

/* ---------- charts ---------- */
function svgBars(opt){
  var W=360,H=210,L=26,B=24,T=10,R=6,iw=W-L-R,ih=H-T-B,n=opt.cols.length,bw=iw/n*0.68,gap=iw/n;
  var max=Math.max.apply(null,opt.cols.map(function(c){return c.total}));var top=Math.max(2,Math.ceil(max/2)*2);
  var h='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+opt.label+'">';
  for(var t=0;t<=top;t+=top>8?4:2){var y=T+ih-ih*t/top;h+='<line class="ax" x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'"/><text class="axt" x="'+(L-5)+'" y="'+(y+3)+'" text-anchor="end">'+t+'</text>'}
  opt.cols.forEach(function(c,i){
    var x=L+gap*i+(gap-bw)/2,acc=0;
    c.parts.forEach(function(p){
      if(!p.v)return;var hh=ih*p.v/top,y=T+ih-ih*(acc+p.v)/top;acc+=p.v;
      h+='<rect class="bar" x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+hh.toFixed(1)+'" rx="2" style="fill:'+p.fill+'" data-tip="'+c.tip+' · '+p.name+': '+p.v+'"/>';
    });
    h+='<text class="axt" x="'+(x+bw/2).toFixed(1)+'" y="'+(H-8)+'" text-anchor="middle">'+c.lab+'</text>';
  });
  return h+'</svg>';
}
function renderCharts(){
  var cols=[],y;
  for(y=2016;y<=2025;y++){
    var list=CY.filter(function(c){return c.y===y});
    cols.push({lab:String(y).slice(2),tip:y+': '+list.length+' storms',total:list.length,
      parts:CATS.map(function(k){return {name:k.n+' ('+k.k+')',v:list.filter(function(c){return c.c===k.k}).length,fill:'var(--c-'+k.k+')'}})});
  }
  $('#chY').innerHTML=svgBars({cols:cols,label:'Storms per year by intensity'})+
    '<div class="legend" style="margin-top:8px">'+CATS.map(function(k){return '<span class="lg"><span class="sw" style="background:var(--c-'+k.k+')"></span>'+k.n+'</span>'}).join('')+'</div>';
  var mc=[],m;
  for(m=1;m<=12;m++){
    var l2=CY.filter(function(c){return +c.s.slice(5,7)===m});
    var b1=l2.filter(function(c){return c.b==='BoB'}).length,a1=l2.length-b1;
    mc.push({lab:MON[m-1].charAt(0),tip:MON[m-1]+': '+l2.length+' storms',total:l2.length,parts:[{name:'Bay of Bengal',v:b1,fill:'var(--bob)'},{name:'Arabian Sea',v:a1,fill:'var(--as)'}]});
  }
  $('#chM').innerHTML=svgBars({cols:mc,label:'Storms by month and basin'})+'<p class="axt" style="margin-top:4px">Months run J (January) to D (December), by month the storm started.</p>';
  $('#lgM').innerHTML='<span class="lg"><span class="sw" style="background:var(--bob)"></span>Bay of Bengal</span><span class="lg"><span class="sw" style="background:var(--as)"></span>Arabian Sea</span>';
  var tot=CY.length,od=CY.filter(function(c){return +c.s.slice(5,7)>=10}).length,ajn=CY.filter(function(c){var x=+c.s.slice(5,7);return x>=4&&x<=6}).length;
  $('#chMNote').textContent='Of the '+tot+' storms in this selected sample, '+od+' began in October–December and '+ajn+' in April–June. Other months see very few storms. These two peaks fall just before and just after the monsoon.';
}


/* ---------- statistical outlook ---------- */
function renderOutlook(){
  var YRS=10,r={BoB:[],AS:[]},m,b;
  for(b in r)for(m=0;m<12;m++)r[b].push(CY.filter(function(c){return c.b===b&&+c.s.slice(5,7)===m+1}).length/YRS);
  var now=new Date(),dim=function(y,mo){return new Date(y,mo+1,0).getDate()};
  function lam(days,bas){var t=0,d=new Date(now);for(var i=0;i<days;i++){var mo=d.getMonth(),dd=dim(d.getFullYear(),mo);
    (bas?[bas]:['BoB','AS']).forEach(function(k){t+=r[k][mo]/dd});d.setDate(d.getDate()+1)}return t}
  var pc=function(l){return Math.round(100*(1-Math.exp(-l)))+'%'};
  var W=[[14,'next 14 days'],[30,'next 30 days'],[60,'next 60 days']],h='';
  W.forEach(function(w){h+='<div class="stat"><b>'+pc(lam(w[0]))+'</b><span>Chance of at least one storm, '+w[1]+' (both basins). Bay of Bengal '+pc(lam(w[0],'BoB'))+', Arabian Sea '+pc(lam(w[0],'AS'))+'</span></div>'});
  $('#olWin').innerHTML=h;
  var cols=[],H=210,Wd=360,L=30,B=24,T=10,iw=Wd-L-6,ih=H-T-B,g=iw/12,bw=g*0.36;
  var svg='<svg viewBox="0 0 '+Wd+' '+H+'" role="img" aria-label="Chance of at least one storm by month">';
  [0,25,50,75].forEach(function(t){var y=T+ih-ih*t/80;svg+='<line class="ax" x1="'+L+'" x2="'+(Wd-6)+'" y1="'+y+'" y2="'+y+'"/><text class="axt" x="'+(L-5)+'" y="'+(y+3)+'" text-anchor="end">'+t+'%</text>'});
  for(m=0;m<12;m++){['BoB','AS'].forEach(function(k,j){
    var p=100*(1-Math.exp(-r[k][m])),hh=ih*p/80,x=L+g*m+g*0.12+j*bw;
    svg+='<rect class="bar" x="'+x.toFixed(1)+'" y="'+(T+ih-hh).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+hh.toFixed(1)+'" rx="2" style="fill:var(--'+(k==='BoB'?'bob':'as')+')" data-tip="'+MON[m]+' · '+BASIN[k]+': '+p.toFixed(0)+'% chance of at least one storm"/>'});
    svg+='<text class="axt" x="'+(L+g*m+g/2).toFixed(1)+'" y="'+(H-8)+'" text-anchor="middle">'+MON[m].charAt(0)+'</text>'}
  $('#olChart').innerHTML=svg+'</svg>';
  var tot=CY.length;
  $('#olInt').innerHTML=CATS.map(function(k){var n=CY.filter(function(c){return c.c===k.k}).length;
    return '<span class="tag"><span class="sw" style="background:var(--c-'+k.k+')"></span> '+k.n+': <b class="mono">'+Math.round(100*n/tot)+'%</b></span>'}).join('');
  var yc=[];for(var y=2016;y<=2025;y++)yc.push(CY.filter(function(c){return c.y===y}).length);
  var mean=yc.reduce(function(a,b){return a+b},0)/yc.length;
  $('#olNote').textContent='Storms in this selected sample average '+mean.toFixed(1)+' a year (range '+Math.min.apply(null,yc)+'–'+Math.max.apply(null,yc)+'). The table is not complete and is skewed towards landfalling or high-impact storms, so these chances are conservative and the strength shares lean high. Ten years is a short record, and this base-rate outlook does not use ENSO, Indian Ocean Dipole, wind shear or sea temperature; those are planned inputs of the ML track model. Use it for context only; IMD bulletins are the real forecast.';
}


/* ---------- landfall pattern ---------- */
var REG={Roanu:'BD',Vardah:'INE',Mora:'BD',Ockhi:'INW',Sagar:'SO',Mekunu:'ARB',Luban:'ARB',Titli:'INE',Gaja:'INE',Phethai:'INE',Fani:'INE',Vayu:'INW',Hikaa:'ARB',Kyarr:'ARB',Maha:'INW',Bulbul:'INE',Amphan:'INE',Nisarga:'INW',Gati:'SO',Nivar:'INE',Tauktae:'INW',Yaas:'INE',Gulab:'INE',Shaheen:'ARB',Asani:'INE',Sitrang:'BD',Mandous:'INE',Mocha:'MM',Biparjoy:'INW',Michaung:'INE',Remal:'BD',Dana:'INE',Fengal:'INE',Shakhti:'ARB',Montha:'INE',Senyar:'OTH',Ditwah:'OTH'};
var RN={INE:['India, east coast','var(--bob)'],INW:['India, west coast','var(--as)'],BD:['Bangladesh','var(--c-SCS)'],MM:['Myanmar','var(--c-ESCS)'],ARB:['Oman / Yemen','var(--c-CS)'],SO:['Somalia','var(--c-SuCS)'],OTH:['Sri Lanka / Indonesia','var(--muted)']};
var PT2='both',ptInit=false;
var GEN={BoB:[88,11.5],AS:[67,13]};
function ptGrp(a,b){return CY.filter(function(c){var m=+c.s.slice(5,7);return m>=a&&m<=b})}
function ptShare(L){var o={};L.forEach(function(c){var k=REG[c.n];o[k]=(o[k]||0)+1});return o}
function compass(dx,dy){var ang=Math.atan2(dy,dx)*180/Math.PI;return ['E','NE','N','NW','W','SW','S','SE'][(Math.round(ang/45)+8)%8]}
function renderPtMap(){
  var box=$('#ptMap'),v=VIEWS.all,vbW=(v[1]-v[0])*K,vbH=(v[3]-v[2])*K,vx=(v[0]-X0)*K,vy=(Y0-v[3])*K;
  box.style.aspectRatio=vbW+' / '+vbH;
  var s=(box.clientWidth||360)/vbW,u=function(n){return +(n/s).toFixed(2)};
  var h='<svg viewBox="'+vx+' '+vy+' '+vbW+' '+vbH+'" role="img" aria-label="Map of typical cyclone directions and landfall regions">';
  h+='<rect class="ocean" x="'+(vx-500)+'" y="'+(vy-500)+'" width="'+(vbW+1000)+'" height="'+(vbH+1000)+'"/>';
  h+='<path class="land" d="'+LAND+'" style="stroke-width:'+u(.9)+'px"/><path class="land" d="'+WATER+'" style="fill:var(--ocean);stroke-width:'+u(.9)+'px"/>';
  var i;
  for(i=50;i<=100;i+=10){h+='<line class="grat" x1="'+px(i)+'" y1="'+vy+'" x2="'+px(i)+'" y2="'+(vy+vbH)+'" style="stroke-width:'+u(.8)+'px"/><text class="gl" x="'+(px(i)+u(3))+'" y="'+(vy+u(11))+'" style="font-size:'+u(10)+'px">'+i+'°E</text>'}
  for(i=10;i<=30;i+=10){h+='<line class="grat" x1="'+vx+'" y1="'+py(i)+'" x2="'+(vx+vbW)+'" y2="'+py(i)+'" style="stroke-width:'+u(.8)+'px"/><text class="gl" x="'+(vx+u(4))+'" y="'+(py(i)-u(3))+'" style="font-size:'+u(10)+'px">'+i+'°N</text>'}
  SEAL.forEach(function(l){if(l[3].indexOf('all')>-1)h+='<text class="sea" x="'+px(l[1])+'" y="'+py(l[2])+'" text-anchor="middle" style="font-size:'+u(12)+'px">'+l[0]+'</text>'});
  CTYL.forEach(function(l){if(l[3].indexOf('all')>-1)h+='<text class="cty" x="'+px(l[1])+'" y="'+py(l[2])+'" text-anchor="middle" style="font-size:'+u(11)+'px">'+l[0]+'</text>'});
  var SE=PT2==='both'?[[4,6,'Apr–Jun',1],[10,12,'Oct–Dec',0]]:(PT2==='AJ'?[[4,6,'Apr–Jun',0]]:[[10,12,'Oct–Dec',0]]);
  var gens={};
  SE.forEach(function(se){
    var L=ptGrp(se[0],se[1]),sh=ptShare(L);
    Object.keys(sh).forEach(function(k){
      var pts=L.filter(function(c){return REG[c.n]===k}),n=pts.length,bas=pts[0].b,g=GEN[bas];gens[bas]=1;
      var la=pts.reduce(function(t,c){return t+c.lat},0)/n,lo=pts.reduce(function(t,c){return t+c.lon},0)/n;
      var x1=px(g[0]),y1=py(g[1]),x2=px(lo),y2=py(la),dx=x2-x1,dy=y2-y1,len=Math.hypot(dx,dy)||1;
      var nx=-dy/len,ny=dx/len;if(ny>0){nx=-nx;ny=-ny}
      var cx=(x1+x2)/2+nx*len*0.2,cy=(y1+y2)/2+ny*len*0.2;
      var hd=compass(lo-g[0],la-g[1]),col=RN[k][1],w=u(1.6+Math.min(n,11)*0.55);
      var tt=se[2]+' · '+RN[k][0]+': '+n+' storm'+(n>1?'s':'')+', mean landfall '+la.toFixed(1)+'°N '+lo.toFixed(1)+'°E, heading '+hd;
      h+='<g data-tip="'+tt+'"><path d="M'+x1+' '+y1+' Q'+cx.toFixed(1)+' '+cy.toFixed(1)+' '+x2.toFixed(1)+' '+y2.toFixed(1)+'" fill="none" stroke="'+col+'" stroke-linecap="round" stroke-opacity=".85" style="stroke-width:'+w+'px'+(se[3]?';stroke-dasharray:'+u(7)+' '+u(5):'')+'"/>';
      var ax=x2-cx,ay=y2-cy,al=Math.hypot(ax,ay)||1;ax/=al;ay/=al;var hs=u(11);
      h+='<polygon points="'+x2.toFixed(1)+','+y2.toFixed(1)+' '+(x2-ax*hs+(-ay)*hs*.5).toFixed(1)+','+(y2-ay*hs+ax*hs*.5).toFixed(1)+' '+(x2-ax*hs-(-ay)*hs*.5).toFixed(1)+','+(y2-ay*hs-ax*hs*.5).toFixed(1)+'" fill="'+col+'"/>';
      var mx=.25*x1+.5*cx+.25*x2,my=.25*y1+.5*cy+.25*y2;
      h+='<text class="sellab" x="'+mx.toFixed(1)+'" y="'+(my-u(4)).toFixed(1)+'" text-anchor="middle" style="font-size:'+u(10)+'px;stroke-width:'+u(3)+'px">'+n+' · '+hd+'</text></g>';
      pts.forEach(function(c){h+='<circle cx="'+px(c.lon)+'" cy="'+py(c.lat)+'" r="'+u(3.4)+'" style="fill:'+col+';stroke:var(--ink);stroke-width:'+u(.8)+'px" data-tip="'+c.n+' '+c.y+' · '+CATN[c.c].n+' · '+c.w+' km/h"/>'});
    });
  });
  Object.keys(gens).forEach(function(b){var g=GEN[b];
    h+='<circle cx="'+px(g[0])+'" cy="'+py(g[1])+'" r="'+u(7)+'" fill="none" stroke="var(--ink)" style="stroke-width:'+u(1.5)+'px;stroke-dasharray:'+u(3)+' '+u(2)+'" data-tip="Typical formation zone (indicative)"/><text class="gl" x="'+(px(g[0])+u(10))+'" y="'+(py(g[1])+u(4))+'" style="font-size:'+u(10)+'px">formation zone</text>'});
  box.innerHTML=h+'</svg>';
  $('#ptMapNote').textContent='Each arrow runs from a typical formation zone (indicative, from general meteorology) to the mean landfall point of that group of storms from the table. Arrow thickness and the first number show how many storms; the letters give the compass heading. Dots are individual landfalls. '+(PT2==='both'?'Dashed arrows are April–June, solid arrows are October–December.':'')+' This shows the usual pattern, not the path of any single storm.';
}
function renderPattern(){
  var G=[['Apr–Jun',4,6],['Oct–Dec',10,12]],keys=Object.keys(RN);
  var cols=[],m;
  for(m=4;m<=12;m++){var L=CY.filter(function(c){return +c.s.slice(5,7)===m}),sh=ptShare(L);
    cols.push({lab:MON[m-1],tip:MON[m-1]+': '+L.length+' storms',total:L.length,parts:keys.map(function(k){return {name:RN[k][0],v:sh[k]||0,fill:RN[k][1]}})})}
  $('#ptMonths').innerHTML=svgBars({cols:cols,label:'Storms by month and landfall region, April to December'});
  $('#ptLeg').innerHTML=keys.map(function(k){return '<span class="lg"><span class="sw" style="background:'+RN[k][1]+'"></span>'+RN[k][0]+'</span>'}).join('');
  function meanLL(a,b){var L=ptGrp(a,b).filter(function(c){return c.b==='BoB'&&['INE','BD','MM'].indexOf(REG[c.n])>-1});
    return {lat:L.reduce(function(t,c){return t+c.lat},0)/L.length,n:L.length}}
  var pre=meanLL(4,6),post=meanLL(10,12);
  $('#ptStats').innerHTML=
    '<div class="stat"><b>'+pre.lat.toFixed(1)+'°N</b><span>Mean landfall latitude, Bay of Bengal, Apr–Jun ('+pre.n+' storms): the northern Bay, from Odisha and West Bengal to Bangladesh and Myanmar</span></div>'+
    '<div class="stat"><b>'+post.lat.toFixed(1)+'°N</b><span>Mean landfall latitude, Bay of Bengal, Oct–Dec ('+post.n+' storms): Tamil Nadu, Andhra Pradesh and south Odisha</span></div>';
  var mo=new Date().getMonth()+1,cur=(mo>=10||mo<=3)?'Oct–Dec':'Apr–Jun',out='';
  G.slice().sort(function(a,b){return (b[0]===cur)-(a[0]===cur)}).forEach(function(g){
    var L=ptGrp(g[1],g[2]),sh=ptShare(L),n=L.length;
    out+='<h3>Where the next storm is most likely to go (based on '+g[0]+' storms, n='+n+')'+(g[0]===cur?' <span class="tag">current season</span>':'')+'</h3><div class="tags">'+
      Object.keys(sh).sort(function(a,b){return sh[b]-sh[a]}).map(function(k){return '<span class="tag"><span class="sw" style="background:'+RN[k][1]+'"></span> '+RN[k][0]+': <b class="mono">'+Math.round(100*sh[k]/n)+'%</b> ('+sh[k]+'/'+n+')</span>'}).join('')+'</div>';
  });
  $('#ptNextBox').innerHTML=out;
  var a=ptShare(ptGrp(4,6)),b=ptShare(ptGrp(10,12));
  var ia=(a.INE||0)+(a.INW||0),ib=(b.INE||0)+(b.INW||0),na=ptGrp(4,6).length,nb=ptGrp(10,12).length;
  $('#ptNote').innerHTML='In Apr–Jun, '+ia+' of '+na+' listed storms ('+Math.round(100*ia/na)+'%) affected India; in Oct–Dec, '+ib+' of '+nb+' ('+Math.round(100*ib/nb)+'%), most of them on the east coast. Direction of travel follows the season: pre-monsoon Bay storms usually turn north or north-east towards Odisha, West Bengal, Bangladesh and Myanmar, while post-monsoon Bay storms usually move west or north-west towards Tamil Nadu and Andhra Pradesh. Arabian Sea storms mostly head west or north-west towards Oman, Yemen and Somalia, and those that curve north-east hit Gujarat. Landfall regions are assigned by hand from the table (storms that weakened offshore are placed at the nearest coast; Amphan and Bulbul are counted as India). The sample is small and is not a forecast of any single storm.';
  renderPtMap();
  if(!ptInit){ptInit=true;
    $('#ptSeg').addEventListener('click',function(e){var bt=e.target.closest('button');if(!bt)return;PT2=bt.dataset.s;
      [].forEach.call($('#ptSeg').children,function(x){x.setAttribute('aria-pressed',x===bt)});renderPtMap()});
    if(window.ResizeObserver){var lw=0;new ResizeObserver(function(){var w=$('#ptMap').clientWidth;if(Math.abs(w-lw)>2){lw=w;renderPtMap()}}).observe($('#ptMap'))}
  }
}

/* ---------- theme ---------- */
var root=document.documentElement;
try{var th=localStorage.getItem('cw-theme');if(th)root.setAttribute('data-theme',th)}catch(e){}
$('#themeBtn').addEventListener('click',function(){
  var cur=root.getAttribute('data-theme')||(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
  var nx=cur==='dark'?'light':'dark';root.setAttribute('data-theme',nx);
  try{localStorage.setItem('cw-theme',nx)}catch(e){}
});

/* ---------- boot ---------- */
renderDetail();renderMap();renderTable();renderAnalog();renderCharts();renderOutlook();renderPattern();
if(window.ResizeObserver){var lastW=0;new ResizeObserver(function(){var w=mapBox.clientWidth;if(Math.abs(w-lastW)>2){lastW=w;renderMap()}}).observe(mapBox)}
runScan();loadCity();
(function(){var N={CS:'Cyclonic Storm',SCS:'Severe Cyclonic Storm',VSCS:'Very Severe',ESCS:'Extremely Severe',SuCS:'Super Cyclone'},o='',el=document.getElementById('catSplit');
if(!el)return;Object.keys(N).forEach(function(k){o+='<span class="tag">'+N[k]+': '+CY.filter(function(c){return c.c===k}).length+'</span>'});el.innerHTML=o})();
})();
