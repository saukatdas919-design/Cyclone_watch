(function(){
'use strict';

/* ============================================================
   Cyclone Watch · Live Map
   Leaflet map with: satellite base, NASA GIBS cloud imagery
   (Himawari IR, VIIRS true colour), RainViewer radar, Open-Meteo
   wind / pressure / temperature / rain fields with a forecast
   timeline, GDACS live storms, the project's watch corridor,
   history 2016-2025 and a hook for the ML model forecast.
   ============================================================ */

var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return [].slice.call((r||document).querySelectorAll(s))};
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function clamp(x,a,b){return Math.max(a,Math.min(b,x))}
function debounce(fn,ms){var t;return function(){var a=arguments,c=this;clearTimeout(t);t=setTimeout(function(){fn.apply(c,a)},ms)}}
function fj(url,ms){
  return new Promise(function(res,rej){
    var c=new AbortController(),t=setTimeout(function(){c.abort()},ms||15000);
    fetch(url,{signal:c.signal}).then(function(r){
      clearTimeout(t);if(!r.ok)throw new Error('HTTP '+r.status);return r.json();
    }).then(res,function(e){clearTimeout(t);rej(e)});
  });
}

var statusEl=$('#status');
function setStatus(msg,kind){statusEl.textContent=msg;statusEl.className='pill status'+(kind?' '+kind:'')}

if(typeof L==='undefined'){setStatus('Map library did not load. Check your internet connection and reload.','bad');return}

/* ---------------- preferences ---------------- */
var PK='cyclonewatch.livemap.v1';
var S={base:'sat',layer:'ir',wind:'kmh',temp:'c',tz:'local',opacity:0.85,
  ov:{storms:true,corridor:true,model:true,past:false,cities:true,labels:true}};
try{
  var sv=JSON.parse(localStorage.getItem(PK)||'null');
  if(sv){for(var k in sv){if(k==='ov'){for(var o in sv.ov){if(o in S.ov)S.ov[o]=sv.ov[o]}}else if(k in S){S[k]=sv[k]}}}
}catch(e){}
function save(){try{localStorage.setItem(PK,JSON.stringify(S))}catch(e){}}

/* ---------------- constants ---------------- */
var LAYERS={
  ir:{name:'Satellite IR',type:'sat'},
  tc:{name:'True colour',type:'day'},
  radar:{name:'Radar',type:'radar'},
  wind:{name:'Wind',type:'field',v:'wind'},
  rain:{name:'Rain',type:'field',v:'rain'},
  temp:{name:'Temperature',type:'field',v:'temp'},
  pres:{name:'Pressure',type:'field',v:'pres'}
};
var REGIONS={bob:[[4,78],[25,100]],as:[[4,48],[26,78]],'in':[[5,66],[36,98]],world:[[-60,-170],[70,170]]};
var CATS={CS:['Cyclonic Storm','#F0D08A'],SCS:['Severe Cyclonic Storm','#F2A24A'],VSCS:['Very Severe Cyclonic Storm','#EC7B2B'],
  ESCS:['Extremely Severe Cyclonic Storm','#E0521F'],SuCS:['Super Cyclonic Storm','#C93313']};
var CITIES=[['Kolkata',22.57,88.36],['Dhaka',23.81,90.41],['Chittagong',22.36,91.78],["Cox's Bazar",21.43,91.98],
  ['Bhubaneswar',20.30,85.82],['Puri',19.81,85.83],['Visakhapatnam',17.69,83.22],['Vijayawada',16.51,80.65],['Chennai',13.08,80.27],
  ['Puducherry',11.93,79.83],['Port Blair',11.62,92.73],['Colombo',6.93,79.85],['Yangon',16.84,96.17],['Sittwe',20.15,92.9],
  ['Mumbai',19.08,72.88],['Surat',21.17,72.83],['Karachi',24.86,67.01],['Muscat',23.59,58.41],['Salalah',17.02,54.09],
  ['Kochi',9.93,76.27],['Thiruvananthapuram',8.52,76.94],['Paradip',20.32,86.61]];

/* ---------------- map ---------------- */
var map=L.map('map',{center:[15,86],zoom:5,minZoom:3,maxZoom:12,zoomControl:false,worldCopyJump:true});
L.control.zoom({position:'topleft'}).addTo(map);
L.control.scale({position:'bottomleft',imperial:false}).addTo(map);
function mkPane(n,z,ev){var p=map.createPane(n);p.style.zIndex=z;if(ev===false)p.style.pointerEvents='none';return p}
mkPane('wx',350,false);mkPane('fld',360,false);mkPane('lbl',450,false);

var BASES={
  sat:{url:'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
       o:{maxZoom:17,attribution:'Imagery © Esri, Maxar, Earthstar Geographics'},
       lbl:'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}'},
  dark:{url:'https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png',
       o:{subdomains:'abcd',maxZoom:19,attribution:'© OpenStreetMap contributors © CARTO'},
       lbl:'https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png'},
  map:{url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
       o:{maxZoom:19,attribution:'© OpenStreetMap contributors'},lbl:null}
};
var baseLyr=null,lblLyr=null;
function setBase(k){
  S.base=k;
  if(baseLyr)map.removeLayer(baseLyr);
  if(lblLyr){map.removeLayer(lblLyr);lblLyr=null}
  var b=BASES[k];
  baseLyr=L.tileLayer(b.url,b.o).addTo(map);
  baseLyr.bringToBack();
  if(b.lbl){
    lblLyr=L.tileLayer(b.lbl,{pane:'lbl',subdomains:'abcd',maxZoom:19,opacity:.95});
    if(S.ov.labels)lblLyr.addTo(map);
  }
  save();refreshButtons();
}

/* ---------------- time formatting ---------------- */
function fmtTime(ms,dateOnly){
  var o=dateOnly?{weekday:'short',day:'numeric',month:'short'}
                :{weekday:'short',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',hour12:false};
  if(S.tz==='utc')o.timeZone='UTC';
  return new Intl.DateTimeFormat('en-GB',o).format(new Date(ms))+((S.tz==='utc'&&!dateOnly)?' UTC':'');
}
function relTag(ms,dateOnly){
  var m=Math.round((ms-Date.now())/6e4),a=Math.abs(m);
  if(dateOnly){var d=Math.round(m/1440);return d===0?'today':(d>0?'in '+d+' d':Math.abs(d)+' d ago')}
  if(a<30)return 'now';
  var h=Math.floor(a/60),mm=a%60,s=(h?h+'h':'')+(mm?(h?' ':'')+mm+'m':'');
  return m<0?s+' ago':'in '+s;
}

/* ---------------- unit helpers ---------------- */
function windU(ms){var u=S.wind;return u==='kmh'?[ms*3.6,'km/h']:u==='kn'?[ms*1.94384,'kn']:u==='mph'?[ms*2.23694,'mph']:[ms,'m/s']}
function tempU(c){return S.temp==='f'?[c*9/5+32,'°F']:[c,'°C']}
var D16=['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
function compass(d){return D16[Math.round(((d%360)+360)%360/22.5)%16]}
function fmtLat(x){return Math.abs(x).toFixed(2)+'°'+(x>=0?'N':'S')}
function fmtLon(x){x=((x+540)%360)-180;return Math.abs(x).toFixed(2)+'°'+(x>=0?'E':'W')}

/* ============================================================
   TIMELINE
   ============================================================ */
var TL={frames:[],idx:0,show:null,timer:null,speed:1,dateOnly:false};
var slider=$('#slider'),playBtn=$('#play');
function renderTL(){
  var f=TL.frames[TL.idx];
  $('#timeline').classList.toggle('off',!TL.frames.length);
  if(!f){$('#tlTime').textContent='–';$('#tlRel').textContent='';return}
  $('#tlTime').textContent=fmtTime(f.t,TL.dateOnly);
  $('#tlRel').textContent=relTag(f.t,TL.dateOnly);
}
function setFrames(frames,idx,show,dateOnly){
  stopPlay();
  TL.frames=frames;TL.show=show;TL.dateOnly=!!dateOnly;
  TL.idx=clamp(idx,0,Math.max(0,frames.length-1));
  slider.max=Math.max(0,frames.length-1);slider.value=TL.idx;
  renderTL();
  if(frames.length&&show)show(TL.idx);
}
function go(i){
  if(!TL.frames.length)return;
  TL.idx=clamp(i,0,TL.frames.length-1);slider.value=TL.idx;renderTL();
  if(TL.show)TL.show(TL.idx);
}
function stopPlay(){if(TL.timer){clearInterval(TL.timer);TL.timer=null}playBtn.innerHTML='&#9654;';playBtn.setAttribute('aria-label','Play')}
function startPlay(){
  if(!TL.frames.length)return;
  stopPlay();
  playBtn.innerHTML='&#10074;&#10074;';playBtn.setAttribute('aria-label','Pause');
  TL.timer=setInterval(function(){go((TL.idx+1)%TL.frames.length)},Math.round(750/TL.speed));
}
function nearestNow(){
  var best=0,bd=1e18;
  TL.frames.forEach(function(f,i){var d=Math.abs(f.t-Date.now());if(d<bd){bd=d;best=i}});
  return best;
}
playBtn.addEventListener('click',function(){TL.timer?stopPlay():startPlay()});
$('#prev').addEventListener('click',function(){stopPlay();go((TL.idx-1+TL.frames.length)%TL.frames.length)});
$('#next').addEventListener('click',function(){stopPlay();go((TL.idx+1)%TL.frames.length)});
$('#nowBtn').addEventListener('click',function(){stopPlay();go(S.layer==='tc'?TL.frames.length-1:nearestNow())});
slider.addEventListener('input',function(){stopPlay();go(+slider.value)});
$('#speed').addEventListener('click',function(){
  var sp=[1,2,4];TL.speed=sp[(sp.indexOf(TL.speed)+1)%sp.length];
  $('#speed').textContent=TL.speed+'×';if(TL.timer)startPlay();
});

/* ============================================================
   IMAGERY LAYERS (satellite, true colour, radar)
   ============================================================ */
var WX={layers:[]};
function clearWx(){
  stopPlay();
  WX.layers.forEach(function(l){map.removeLayer(l)});WX.layers=[];
  FLD.on=false;fieldToken++;hideField();
}
function gibsIR(t){
  var iso=new Date(t).toISOString().slice(0,19)+'Z';
  return 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/Himawari_AHI_Band13_Clean_Infrared/default/'+iso+'/GoogleMapsCompatible_Level6/{z}/{y}/{x}.png';
}
function gibsDay(t){
  var d=new Date(t).toISOString().slice(0,10);
  return 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_SNPP_CorrectedReflectance_TrueColor/default/'+d+'/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg';
}
function frameLayers(frames,idx,opts,msg){
  frames.forEach(function(f){
    f.lyr=L.tileLayer(f.url,opts).addTo(map);WX.layers.push(f.lyr);
  });
  setFrames(frames,idx,function(i){frames.forEach(function(f,k){f.lyr.setOpacity(k===i?S.opacity:0)})});
  setStatus(msg,'ok');
}
function loadIR(){
  var step=20*60e3,latest=Math.floor((Date.now()-70*60e3)/step)*step,n=13,fr=[];
  for(var i=0;i<n;i++){var t=latest-(n-1-i)*step;fr.push({t:t,url:gibsIR(t)})}
  frameLayers(fr,n-1,{pane:'wx',opacity:0,maxNativeZoom:6,maxZoom:14,attribution:'Himawari IR via NASA GIBS'},
    'Himawari IR · NASA GIBS');
}
function loadDay(){
  var days=[],now=new Date();
  for(var i=9;i>=0;i--){days.push({t:Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()-i)})}
  var lyr=L.tileLayer(gibsDay(days[8].t),{pane:'wx',opacity:S.opacity,maxNativeZoom:9,maxZoom:14,attribution:'VIIRS via NASA GIBS'}).addTo(map);
  WX.layers.push(lyr);
  setFrames(days,8,function(i){lyr.setUrl(gibsDay(days[i].t));lyr.setOpacity(S.opacity)},true);
  setStatus('VIIRS true colour · NASA GIBS (daily)','ok');
}
function loadRadar(){
  setStatus('Loading radar…');
  var tok=++fieldToken;
  fj('https://api.rainviewer.com/public/weather-maps.json',12000).then(function(d){
    if(tok!==fieldToken||S.layer!=='radar')return;
    var host=d.host||'https://tilecache.rainviewer.com';
    var all=((d.radar&&d.radar.past)||[]).concat((d.radar&&d.radar.nowcast)||[]);
    if(!all.length)throw new Error('no frames');
    var fr=all.map(function(f){return {t:f.time*1000,url:host+f.path+'/256/{z}/{x}/{y}/2/1_1.png'}});
    var past=((d.radar&&d.radar.past)||[]).length;
    frameLayers(fr,Math.max(0,past-1),{pane:'wx',opacity:0,maxNativeZoom:7,maxZoom:14,attribution:'Radar © RainViewer'},
      'Radar · RainViewer');
  }).catch(function(){
    if(tok===fieldToken)setStatus('Radar feed unavailable right now','bad');
  });
}

/* ============================================================
   WEATHER FIELDS (Open-Meteo grid): wind particles, pressure,
   temperature, rain, with a 48-hour forecast timeline
   ============================================================ */
var FLD={on:false,v:'wind',k:0};
var G=null,fieldToken=0,gridCache={};
var fcv=L.DomUtil.create('canvas','fcv',map.getPane('fld'));
var pcv=L.DomUtil.create('canvas','fcv',map.getPane('fld'));
var fctx=fcv.getContext('2d'),pctx=pcv.getContext('2d');
var off=document.createElement('canvas'),octx=off.getContext('2d');
var STEP=8,VU=null,VV=null,VW=0,VH=0;

var SC={
  wind:{t:'Wind speed',st:[[0,[44,90,170,1]],[4,[60,160,200,1]],[8,[90,200,120,1]],[12,[240,220,70,1]],[18,[240,140,50,1]],[24,[220,60,60,1]],[32,[170,40,170,1]]],a:.55},
  pres:{t:'Sea-level pressure',st:[[980,[110,60,170,1]],[995,[60,110,200,1]],[1005,[80,190,200,1]],[1013,[120,200,120,1]],[1020,[230,220,100,1]],[1030,[240,150,70,1]],[1040,[200,70,60,1]]],a:.55},
  temp:{t:'Temperature (2 m)',st:[[-10,[120,80,200,1]],[0,[60,130,220,1]],[10,[80,200,200,1]],[20,[120,210,100,1]],[28,[240,220,70,1]],[35,[240,130,50,1]],[45,[200,40,40,1]]],a:.55},
  rain:{t:'Precipitation (per hour)',st:[[0,[0,0,0,0]],[.2,[150,210,255,.35]],[1,[70,150,240,.65]],[3,[40,200,120,.75]],[6,[240,220,70,.85]],[12,[240,110,50,.9]],[20,[200,40,120,.95]]],a:.85}
};
Object.keys(SC).forEach(function(k){
  var s=SC[k],lo=s.st[0][0],hi=s.st[s.st.length-1][0],N=512,lut=new Uint8ClampedArray(N*4);
  for(var i=0;i<N;i++){
    var v=lo+(hi-lo)*i/(N-1),j=0;
    while(j<s.st.length-2&&v>s.st[j+1][0])j++;
    var a=s.st[j],b=s.st[j+1],f=clamp((v-a[0])/(b[0]-a[0]),0,1);
    for(var c=0;c<4;c++)lut[i*4+c]=(a[1][c]+(b[1][c]-a[1][c])*f)*(c===3?255:1);
  }
  s.lo=lo;s.hi=hi;s.lut=lut;
});

function normLon(x){return ((x+540)%360)-180}
function loadField(){
  var tok=++fieldToken;
  var b=map.getBounds().pad(0.25);
  var s=Math.max(-80,b.getSouth()),n=Math.min(80,b.getNorth()),w=b.getWest(),e=b.getEast(),world=false;
  if(e-w>=340){w=-180;e=180;world=true}
  var nx=12,ny=9,la=[],lo=[];
  for(var j=0;j<ny;j++)for(var i=0;i<nx;i++){
    la.push((s+(n-s)*j/(ny-1)).toFixed(2));
    lo.push(normLon(w+(e-w)*i/(nx-1)).toFixed(2));
  }
  setStatus('Loading '+LAYERS[S.layer].name.toLowerCase()+' forecast…');
  var url='https://api.open-meteo.com/v1/forecast?latitude='+la.join(',')+'&longitude='+lo.join(',')+
    '&hourly=wind_speed_10m,wind_direction_10m,pressure_msl,temperature_2m,precipitation'+
    '&forecast_hours=49&wind_speed_unit=ms&timezone=GMT';
  fj(url,30000).then(function(r){
    if(tok!==fieldToken||!FLD.on)return;
    if(!Array.isArray(r))r=[r];
    if(!r[0]||!r[0].hourly)throw new Error('bad response');
    var times=r[0].hourly.time.map(function(t){return Date.parse(t+':00Z')});
    function col(name){return r.map(function(p){return (p.hourly[name]||[]).map(function(x){return x==null?0:x})})}
    G={s:s,n:n,w:w,e:e,nx:nx,ny:ny,world:world,z:map.getZoom(),times:times,
       v:{wind:col('wind_speed_10m'),dir:col('wind_direction_10m'),pres:col('pressure_msl'),temp:col('temperature_2m'),rain:col('precipitation')}};
    gridCache={};
    var keep=FLD.hold;FLD.hold=null;
    var start=0;
    if(keep!=null){for(var q=0;q<times.length;q++){if(times[q]>=keep){start=q;break}}}
    setFrames(times.map(function(t){return {t:t}}),start,function(i){FLD.k=i;renderField()});
    setStatus('Open-Meteo forecast · '+LAYERS[S.layer].name,'ok');
  }).catch(function(){
    if(tok===fieldToken)setStatus('Weather data unavailable right now','bad');
  });
}
function gridFor(name,k){
  var key=name+k;if(gridCache[key])return gridCache[key];
  var n=G.nx*G.ny,a=new Float32Array(n),i;
  if(name==='u'||name==='v'){
    for(i=0;i<n;i++){
      var sp=G.v.wind[i][k]||0,dr=(G.v.dir[i][k]||0)*Math.PI/180;
      a[i]=name==='u'?-sp*Math.sin(dr):-sp*Math.cos(dr);
    }
  }else{for(i=0;i<n;i++)a[i]=G.v[name][i][k]||0}
  gridCache[key]=a;return a;
}
function wrapLon(lo){var c=(G.w+G.e)/2;while(lo<c-180)lo+=360;while(lo>c+180)lo-=360;return lo}
function bil(arr,lat,lon){
  var fx=(wrapLon(lon)-G.w)/(G.e-G.w)*(G.nx-1),fy=(lat-G.s)/(G.n-G.s)*(G.ny-1);
  if(!(fx>=0&&fy>=0&&fx<=G.nx-1&&fy<=G.ny-1))return NaN;
  var x0=Math.floor(fx),y0=Math.floor(fy),x1=Math.min(x0+1,G.nx-1),y1=Math.min(y0+1,G.ny-1),tx=fx-x0,ty=fy-y0,nx=G.nx;
  var a=arr[y0*nx+x0],b=arr[y0*nx+x1],c=arr[y1*nx+x0],d=arr[y1*nx+x1];
  return (a*(1-tx)+b*tx)*(1-ty)+(c*(1-tx)+d*tx)*ty;
}
function hideField(){
  fcv.style.display='none';pcv.style.display='none';stopParticles();
  $('#legend').hidden=true;
}
function renderField(){
  if(!FLD.on||!G)return;
  var size=map.getSize(),W=size.x,H=size.y,v=FLD.v,sc=SC[v];
  var tl=map.containerPointToLayerPoint([0,0]);
  [fcv,pcv].forEach(function(c){
    if(c.width!==W||c.height!==H){c.width=W;c.height=H}
    L.DomUtil.setPosition(c,tl);c.style.display='block';
  });
  var cw=Math.ceil(W/STEP),ch=Math.ceil(H/STEP);
  off.width=cw;off.height=ch;
  var img=octx.createImageData(cw,ch),px=img.data,main=gridFor(v==='wind'?'wind':v,FLD.k);
  var gu=gridFor('u',FLD.k),gv=gridFor('v',FLD.k),wantVec=(v==='wind');
  VW=cw;VH=ch;
  if(wantVec){VU=new Float32Array(cw*ch);VV=new Float32Array(cw*ch)}
  var lut=sc.lut,span=sc.hi-sc.lo;
  for(var y=0;y<ch;y++){
    for(var x=0;x<cw;x++){
      var ll=map.containerPointToLatLng(L.point(x*STEP+STEP/2,y*STEP+STEP/2));
      var val=bil(main,ll.lat,ll.lng),o=(y*cw+x)*4,i4;
      if(wantVec){
        var uu=bil(gu,ll.lat,ll.lng),vv=bil(gv,ll.lat,ll.lng);
        VU[y*cw+x]=uu;VV[y*cw+x]=vv;
      }
      if(val!==val){px[o+3]=0;continue}
      i4=Math.round(clamp((val-sc.lo)/span,0,1)*511)*4;
      px[o]=lut[i4];px[o+1]=lut[i4+1];px[o+2]=lut[i4+2];px[o+3]=lut[i4+3]*sc.a;
    }
  }
  octx.putImageData(img,0,0);
  fctx.clearRect(0,0,W,H);fctx.imageSmoothingEnabled=true;
  fctx.globalAlpha=Math.min(1,S.opacity+.1);
  fctx.drawImage(off,0,0,cw*STEP,ch*STEP);fctx.globalAlpha=1;
  drawLegend(v);
  if(wantVec){pcv.style.display='block';startParticles(W,H)}else{stopParticles();pctx.clearRect(0,0,W,H);pcv.style.display='none'}
}

/* particles (wind) */
var P={run:false,n:0,x:null,y:null,a:null,raf:0,W:0,H:0};
function spawn(i,rand){P.x[i]=Math.random()*P.W;P.y[i]=Math.random()*P.H;P.a[i]=rand?Math.random()*90:0}
function startParticles(W,H){
  P.W=W;P.H=H;
  var n=Math.min(4500,Math.floor(W*H/450));
  if(n!==P.n||!P.x){P.n=n;P.x=new Float32Array(n);P.y=new Float32Array(n);P.a=new Float32Array(n);for(var i=0;i<n;i++)spawn(i,true)}
  pctx.clearRect(0,0,W,H);
  if(!P.run){P.run=true;P.raf=requestAnimationFrame(stepParticles)}
}
function stopParticles(){P.run=false;if(P.raf)cancelAnimationFrame(P.raf);P.raf=0}
function stepParticles(){
  if(!P.run)return;
  var W=P.W,H=P.H,k=clamp(0.09*(1+(map.getZoom()-4)*0.15),0.05,0.3);
  pctx.globalCompositeOperation='destination-out';
  pctx.fillStyle='rgba(0,0,0,0.07)';pctx.fillRect(0,0,W,H);
  pctx.globalCompositeOperation='source-over';
  pctx.strokeStyle='rgba(255,255,255,0.85)';pctx.lineWidth=1.1;
  pctx.beginPath();
  for(var i=0;i<P.n;i++){
    var x=P.x[i],y=P.y[i];
    var gx=(x/STEP)|0,gy=(y/STEP)|0;
    if(gx<0||gy<0||gx>=VW||gy>=VH||P.a[i]>90){spawn(i,false);continue}
    var u=VU[gy*VW+gx],v=VV[gy*VW+gx];
    if(u!==u||v!==v){spawn(i,false);continue}
    var nx=x+u*k,ny=y-v*k;
    pctx.moveTo(x,y);pctx.lineTo(nx,ny);
    P.x[i]=nx;P.y[i]=ny;P.a[i]+=1;
  }
  pctx.stroke();
  P.raf=requestAnimationFrame(stepParticles);
}

function sampleAt(ll){
  if(!FLD.on||!G)return '';
  var v=FLD.v,k=FLD.k;
  if(v==='wind'){
    var u=bil(gridFor('u',k),ll.lat,ll.lng),w=bil(gridFor('v',k),ll.lat,ll.lng);
    if(u!==u)return '';
    var sp=Math.hypot(u,w),from=(Math.atan2(-u,-w)*180/Math.PI+360)%360,c=windU(sp);
    return 'Wind '+c[0].toFixed(0)+' '+c[1]+' from '+compass(from);
  }
  var x=bil(gridFor(v,k),ll.lat,ll.lng);if(x!==x)return '';
  if(v==='pres')return x.toFixed(0)+' hPa';
  if(v==='temp'){var t=tempU(x);return t[0].toFixed(1)+' '+t[1]}
  return x.toFixed(1)+' mm/h';
}

/* legend */
function drawLegend(v){
  var el=$('#legend'),sc=SC[v];
  var stops=sc.st.map(function(s){
    var p=((s[0]-sc.lo)/(sc.hi-sc.lo)*100).toFixed(1),c=s[1];
    return 'rgba('+c[0]+','+c[1]+','+c[2]+','+Math.max(.15,c[3])+') '+p+'%';
  }).join(',');
  function lab(x){
    if(v==='wind')return windU(x)[0].toFixed(0);
    if(v==='temp')return tempU(x)[0].toFixed(0);
    return v==='rain'?x.toFixed(0):x.toFixed(0);
  }
  var unit=v==='wind'?windU(1)[1]:v==='temp'?tempU(0)[1]:v==='pres'?'hPa':'mm/h';
  var ticks=[0,.25,.5,.75,1].map(function(f){return '<span>'+lab(sc.lo+(sc.hi-sc.lo)*f)+'</span>'}).join('');
  el.innerHTML='<div class="t">'+esc(sc.t)+' · '+esc(unit)+'</div><div class="bar" style="background:linear-gradient(90deg,'+stops+')"></div><div class="tk">'+ticks+'</div>';
  el.hidden=false;
}
function drawSimpleLegend(txt){
  var el=$('#legend');el.innerHTML='<div class="src">'+esc(txt)+'</div>';el.hidden=false;
}

function fieldCovers(){
  if(!G)return false;
  if(Math.abs(map.getZoom()-G.z)>=2)return false;
  if(G.world)return true;
  var b=map.getBounds();
  return b.getSouth()>=G.s-1&&b.getNorth()<=G.n+1&&b.getWest()>=G.w&&b.getEast()<=G.e;
}
var reloadField=debounce(function(){if(FLD.on){FLD.hold=TL.frames[TL.idx]?TL.frames[TL.idx].t:null;loadField()}},700);
map.on('movestart',function(){if(FLD.on){stopParticles();pcv.style.display='none'}});
map.on('zoomstart',function(){if(FLD.on){fcv.style.display='none'}});
map.on('moveend',function(){
  if(!FLD.on)return;
  if(G&&fieldCovers())renderField();else{fcv.style.display='none';reloadField()}
});

function selectLayer(key){
  S.layer=key;save();
  clearWx();
  var def=LAYERS[key];
  refreshButtons();
  if(def.type==='sat'){loadIR();drawSimpleLegend('Himawari infrared cloud imagery · covers ~60°E–180°')}
  else if(def.type==='day'){loadDay();drawSimpleLegend('VIIRS true colour · daily · partial for today')}
  else if(def.type==='radar'){loadRadar();drawSimpleLegend('Rain radar · RainViewer · where radar coverage exists')}
  else{FLD.on=true;FLD.v=def.v;setFrames([],0,null);if(G&&fieldCovers()){
      setFrames(G.times.map(function(t){return {t:t}}),0,function(i){FLD.k=i;renderField()});
      setStatus('Open-Meteo forecast · '+def.name,'ok');
    }else{loadField()}}
  try{history.replaceState(null,'','#'+map.getCenter().lat.toFixed(2)+','+map.getCenter().lng.toFixed(2)+','+map.getZoom()+','+key)}catch(e){}
}

/* ============================================================
   STORMS & OVERLAYS
   ============================================================ */
var gLive=L.layerGroup(),gWatch=L.layerGroup(),gModel=L.layerGroup(),gPast=L.layerGroup(),gCities=L.layerGroup();
var STORMS={live:[],model:[],liveErr:false};

/* watch corridor (indicative, from IMD's stated direction only) */
var TRK=[[92.5,10.5],[88.5,11.2],[84.8,12.0],[81.6,13.0],[80.3,13.4]],HW=[0.8,1.4,2.0,2.6,3.0];
var UP=[{n:1,lon:94.3,lat:12.9,t:'~11 Oct: possible upper-air cyclonic circulation, north Andaman Sea'},
        {n:2,lon:92.5,lat:10.5,t:'~13 Oct: possible low-pressure area, south-east Bay of Bengal (position approximate)'},
        {n:3,lon:80.3,lat:13.4,t:'~16–17 Oct: towards north Tamil Nadu–south Andhra coast (possible)'}];
function buildWatch(){
  gWatch.clearLayers();
  var Lp=[],Rp=[];
  for(var i=0;i<TRK.length;i++){
    var a=TRK[Math.max(0,i-1)],b=TRK[Math.min(TRK.length-1,i+1)];
    var dx=b[0]-a[0],dy=b[1]-a[1],n=Math.hypot(dx,dy)||1,nx=-dy/n,ny=dx/n;
    Lp.push([TRK[i][1]+ny*HW[i],TRK[i][0]+nx*HW[i]]);
    Rp.unshift([TRK[i][1]-ny*HW[i],TRK[i][0]-nx*HW[i]]);
  }
  L.polygon(Lp.concat(Rp),{color:'#ff6b4a',weight:1.5,dashArray:'6 6',fillColor:'#ff6b4a',fillOpacity:.14,bubblingMouseEvents:false})
    .bindPopup('<b>Indicative corridor</b><br>Drawn only from the direction in the IMD-based report (west-north-westwards for 3–4 days). Not an official forecast.').addTo(gWatch);
  L.polyline(TRK.map(function(p){return [p[1],p[0]]}),{color:'#ff6b4a',weight:2,dashArray:'2 6',interactive:false}).addTo(gWatch);
  UP.forEach(function(p){
    L.marker([p.lat,p.lon],{icon:L.divIcon({className:'',iconSize:[26,26],iconAnchor:[13,13],
      html:'<div style="width:26px;height:26px;border-radius:50%;background:#ffcf4d;color:#0b131d;font-weight:700;display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 0 6px #000">'+p.n+'</div>'}),
      title:p.t}).bindPopup('<b>Step '+p.n+'</b><br>'+esc(p.t)+'<br><small>Source: Sambad English, 9 Oct 2026, citing IMD. Not an official warning.</small>').addTo(gWatch);
  });
}

/* history */
function buildPast(){
  gPast.clearLayers();
  (window.CYCLONE_RAW||[]).forEach(function(r){
    var c=CATS[r[5]]||['Cyclone','#ccc'],kmh=r[6],weak=String(r[12]).indexOf('n')>-1;
    var m=L.circleMarker([r[9],r[10]],{radius:4+Math.sqrt(kmh)*0.45,color:'#fff',weight:1,fillColor:c[1],fillOpacity:.85,dashArray:weak?'3 3':null,bubblingMouseEvents:false});
    var w=windU(kmh/3.6);
    m.bindPopup('<div class="pw"><h3>'+esc(r[1])+' ('+r[0]+')</h3>'+esc(c[0])+'<table>'+
      '<tr><td>Peak wind</td><td>'+w[0].toFixed(0)+' '+w[1]+'</td></tr>'+
      '<tr><td>Min. pressure</td><td>'+r[7]+' hPa</td></tr>'+
      '<tr><td>Dates</td><td>'+esc(r[2])+' → '+esc(r[3])+'</td></tr>'+
      '<tr><td>Landfall / end</td><td>'+esc(r[8])+'</td></tr>'+
      '<tr><td>Deaths</td><td>'+(r[11]==null?'—':(String(r[12]).indexOf('>')>-1?'≥':(String(r[12]).indexOf('~')>-1?'~':''))+r[11])+'</td></tr></table></div>').addTo(gPast);
  });
}

/* cities */
function buildCities(){
  gCities.clearLayers();
  CITIES.forEach(function(c){
    var m=L.circleMarker([c[1],c[2]],{radius:3.5,color:'#fff',weight:1,fillColor:'#0b131d',fillOpacity:1,bubblingMouseEvents:false});
    m.bindTooltip(c[0],{permanent:true,direction:'right',offset:[5,0],className:'city'});
    m.on('click',function(){openWeather(L.latLng(c[1],c[2]),c[0])});
    m.addTo(gCities);
  });
}

/* model forecast hook */
function buildModel(){
  gModel.clearLayers();STORMS.model=[];
  var M=window.MODEL_FORECAST;
  if(!M||!M.storms)return;
  M.storms.forEach(function(s){
    var tr=(s.track||[]).filter(function(p){return typeof p.lat==='number'&&typeof p.lon==='number'});
    if(!tr.length)return;
    STORMS.model.push({name:s.name||'Model forecast',lat:tr[0].lat,lon:tr[0].lon,issued:M.issued,hours:tr[tr.length-1].h});
    L.polyline(tr.map(function(p){return [p.lat,p.lon]}),{color:'#ffd24a',weight:3,interactive:false}).addTo(gModel);
    tr.forEach(function(p){
      if(p.radius_km)L.circle([p.lat,p.lon],{radius:p.radius_km*1000,color:'#ffd24a',weight:1,fillColor:'#ffd24a',fillOpacity:.12,interactive:false}).addTo(gModel);
      var w=p.wind_kmh!=null?windU(p.wind_kmh/3.6):null;
      L.circleMarker([p.lat,p.lon],{radius:5,color:'#fff',weight:1.5,fillColor:'#ffd24a',fillOpacity:1,bubblingMouseEvents:false})
        .bindTooltip('+'+(p.h||0)+'h'+(w?' · '+w[0].toFixed(0)+' '+w[1]:''),{className:'trk',direction:'top'})
        .addTo(gModel);
    });
  });
}

/* live storms from GDACS */
var ALERT_COL={red:'#ff5d4d',orange:'#ff9d3d',green:'#52c48a'};
function stormIcon(col){
  return L.divIcon({className:'stormico',iconSize:[34,34],iconAnchor:[17,17],
    html:'<svg viewBox="0 0 40 40"><path d="M20 20 C20 13 29 13 29 20 C29 29 12 29 12 20 C12 9 32 6 34 20" fill="none" stroke="'+col+'" stroke-width="3.5" stroke-linecap="round"/><circle cx="20" cy="20" r="3.2" fill="#fff"/></svg>'});
}
function loadLiveStorms(){
  var to=new Date(),from=new Date(Date.now()-12*864e5);
  function d(x){return x.toISOString().slice(0,10)}
  var url='https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH?eventlist=TC&fromDate='+d(from)+'&toDate='+d(to)+'&alertlevel=Green;Orange;Red';
  return fj(url,15000).then(function(j){
    var fs=(j&&j.features)||[];
    STORMS.live=fs.filter(function(f){
      var p=f.properties||{};return f.geometry&&f.geometry.type==='Point'&&(String(p.iscurrent)==='true'||p.iscurrent===true);
    }).map(function(f){
      var p=f.properties||{},sev=p.severitydata||{},alert=String(p.alertlevel||'Green').toLowerCase();
      return {name:p.name||p.eventname||'Unnamed',alert:alert,sev:sev.severitytext||'',country:p.country||'',
        from:p.fromdate,to:p.todate,lat:f.geometry.coordinates[1],lon:f.geometry.coordinates[0],
        link:(p.url&&p.url.report)||'https://www.gdacs.org/'};
    });
    STORMS.liveErr=false;
  }).catch(function(){STORMS.liveErr=true;STORMS.live=[]});
}
function buildLive(){
  gLive.clearLayers();
  STORMS.live.forEach(function(s){
    var col=ALERT_COL[s.alert]||'#fff';
    L.marker([s.lat,s.lon],{icon:stormIcon(col),title:s.name})
      .bindPopup('<div class="pw"><h3>'+esc(s.name)+'</h3><span class="tag '+esc(s.alert)+'">'+esc(s.alert.toUpperCase())+'</span> '+esc(s.sev)+
        '<table><tr><td>Position</td><td>'+fmtLat(s.lat)+' '+fmtLon(s.lon)+'</td></tr>'+
        (s.country?'<tr><td>Affected</td><td>'+esc(s.country)+'</td></tr>':'')+'</table>'+
        '<p class="m" style="margin:8px 0 0">Source: GDACS. <a href="'+esc(s.link)+'" target="_blank" rel="noopener">Open report</a></p></div>').addTo(gLive);
  });
}

/* storm list panel */
function renderStormList(){
  var h='';
  h+='<button class="storm-item" type="button" data-fly="12,86,5"><b><span class="tag watch">WATCH</span>Bay of Bengal low-pressure</b><span>Possible low forming ~13 Oct; possible approach to north Tamil Nadu–south Andhra ~16–17 Oct. Based on an IMD-sourced news report.</span></button>';
  STORMS.model.forEach(function(s){
    h+='<button class="storm-item" type="button" data-fly="'+s.lat+','+s.lon+',6"><b><span class="tag model">MODEL</span>'+esc(s.name)+'</b><span>Project model track out to +'+s.hours+' h.</span></button>';
  });
  STORMS.live.forEach(function(s){
    h+='<button class="storm-item" type="button" data-fly="'+s.lat+','+s.lon+',6"><b><span class="tag '+esc(s.alert)+'">'+esc(s.alert.toUpperCase())+'</span>'+esc(s.name)+'</b><span>'+esc(s.sev||'Active tropical cyclone')+(s.country?' · '+esc(s.country):'')+'</span></button>';
  });
  if(!STORMS.live.length){
    h+='<p class="empty">'+(STORMS.liveErr?'The live storm feed (GDACS) could not be reached.':'No active tropical cyclones reported worldwide in the GDACS feed right now.')+'</p>';
  }
  $('#stormList').innerHTML=h;
}
$('#stormList').addEventListener('click',function(e){
  var b=e.target.closest('[data-fly]');if(!b)return;
  var p=b.dataset.fly.split(',').map(Number);map.flyTo([p[0],p[1]],p[2],{duration:1.2});
  if(window.innerWidth<=760)togglePanel('storms',false);
});

function applyOverlays(){
  function set(g,on){if(on){if(!map.hasLayer(g))map.addLayer(g)}else if(map.hasLayer(g))map.removeLayer(g)}
  set(gLive,S.ov.storms);set(gWatch,S.ov.corridor);set(gModel,S.ov.model);set(gPast,S.ov.past);set(gCities,S.ov.cities);
  if(lblLyr)set(lblLyr,S.ov.labels);
  $$('[data-ov]').forEach(function(c){c.checked=!!S.ov[c.dataset.ov]});
}

/* ============================================================
   POINT WEATHER POPUP
   ============================================================ */
var WC={0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Rime fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',
  61:'Light rain',63:'Rain',65:'Heavy rain',71:'Light snow',73:'Snow',75:'Heavy snow',80:'Rain showers',81:'Showers',82:'Violent showers',
  95:'Thunderstorm',96:'Thunderstorm, hail',99:'Severe thunderstorm, hail'};
var wxTok=0;
function openWeather(ll,title){
  var tok=++wxTok,pop=L.popup({maxWidth:300}).setLatLng(ll).setContent('<div class="pw">Loading weather…</div>').openOn(map);
  var url='https://api.open-meteo.com/v1/forecast?latitude='+ll.lat.toFixed(3)+'&longitude='+normLon(ll.lng).toFixed(3)+
    '&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code'+
    '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,weather_code&timezone=auto&forecast_days=4&wind_speed_unit=ms';
  fj(url,15000).then(function(r){
    if(tok!==wxTok)return;
    var c=r.current,d=r.daily,t=tempU(c.temperature_2m),ap=tempU(c.apparent_temperature),w=windU(c.wind_speed_10m),g=windU(c.wind_gusts_10m);
    var days='';
    for(var i=0;i<4;i++){
      var dd=new Date(d.time[i]+'T12:00:00Z'),hi=tempU(d.temperature_2m_max[i]),lo=tempU(d.temperature_2m_min[i]);
      days+='<div><b>'+(i===0?'Today':dd.toLocaleDateString('en-GB',{weekday:'short',timeZone:'UTC'}))+'</b><br>'+hi[0].toFixed(0)+'° / '+lo[0].toFixed(0)+'°<br><span class="m">'+d.precipitation_sum[i].toFixed(0)+' mm</span></div>';
    }
    pop.setContent('<div class="pw"><h3>'+esc(title||'Selected point')+'</h3><span class="m">'+fmtLat(ll.lat)+' '+fmtLon(ll.lng)+'</span>'+
      '<div class="big">'+t[0].toFixed(0)+t[1]+'</div><div>'+esc(WC[c.weather_code]||'—')+' · feels '+ap[0].toFixed(0)+'°</div>'+
      '<table><tr><td>Wind</td><td>'+w[0].toFixed(0)+' '+w[1]+' '+compass(c.wind_direction_10m)+'</td></tr>'+
      '<tr><td>Gusts</td><td>'+g[0].toFixed(0)+' '+g[1]+'</td></tr>'+
      '<tr><td>Pressure</td><td>'+c.pressure_msl.toFixed(0)+' hPa</td></tr>'+
      '<tr><td>Humidity</td><td>'+c.relative_humidity_2m+'%</td></tr>'+
      '<tr><td>Cloud cover</td><td>'+c.cloud_cover+'%</td></tr>'+
      '<tr><td>Rain now</td><td>'+c.precipitation+' mm</td></tr></table>'+
      '<div class="days">'+days+'</div><p class="m" style="margin:8px 0 0;font-size:11.5px">Open-Meteo model data, not an official forecast.</p></div>');
  }).catch(function(){
    if(tok===wxTok)pop.setContent('<div class="pw">Could not load weather for this point.</div>');
  });
}
map.on('click',function(e){openWeather(e.latlng)});

/* coordinates readout */
var coord=$('#coord');
map.on('mousemove',function(e){
  var s=fmtLat(e.latlng.lat)+'  '+fmtLon(e.latlng.lng),v=sampleAt(e.latlng);
  coord.textContent=s+(v?'  ·  '+v:'');
});
map.on('mouseout',function(){coord.textContent=''});

/* ============================================================
   SEARCH, LOCATION, PANELS
   ============================================================ */
var q=$('#q'),sug=$('#sug');
var doSearch=debounce(function(){
  var v=q.value.trim();
  if(v.length<2){sug.hidden=true;return}
  fj('https://geocoding-api.open-meteo.com/v1/search?name='+encodeURIComponent(v)+'&count=6&language=en&format=json',10000).then(function(r){
    var rs=r.results||[];
    if(!rs.length){sug.innerHTML='<li>No places found</li>';sug.hidden=false;return}
    sug.innerHTML=rs.map(function(p,i){
      return '<li tabindex="0" data-i="'+i+'">'+esc(p.name)+'<small>'+esc([p.admin1,p.country].filter(Boolean).join(', '))+'</small></li>';
    }).join('');
    sug._rs=rs;sug.hidden=false;
  }).catch(function(){sug.innerHTML='<li>Search unavailable</li>';sug.hidden=false});
},300);
q.addEventListener('input',doSearch);
function pick(li){
  if(!li||li.dataset.i==null)return;
  var p=sug._rs[+li.dataset.i];sug.hidden=true;q.value=p.name;
  map.flyTo([p.latitude,p.longitude],8,{duration:1.2});
  map.once('moveend',function(){openWeather(L.latLng(p.latitude,p.longitude),p.name)});
}
sug.addEventListener('click',function(e){pick(e.target.closest('li'))});
sug.addEventListener('keydown',function(e){if(e.key==='Enter')pick(e.target.closest('li'))});
document.addEventListener('click',function(e){if(!e.target.closest('.search'))sug.hidden=true});

var myMark=null;
$('#locBtn').addEventListener('click',function(){
  if(!navigator.geolocation){setStatus('Location is not available in this browser','bad');return}
  setStatus('Finding your location…');
  navigator.geolocation.getCurrentPosition(function(p){
    var ll=L.latLng(p.coords.latitude,p.coords.longitude);
    if(myMark)map.removeLayer(myMark);
    myMark=L.circleMarker(ll,{radius:7,color:'#fff',weight:2,fillColor:'#3b82f6',fillOpacity:1}).addTo(map);
    map.flyTo(ll,8,{duration:1.2});map.once('moveend',function(){openWeather(ll,'Your location')});
    setStatus('Location found','ok');
  },function(){setStatus('Location permission denied or unavailable','bad')},{timeout:10000});
});

function togglePanel(which,force){
  var map_={layers:['#layers','#menuBtn'],storms:['#storms','#stormBtn']},t=map_[which];
  var el=$(t[0]),btn=$(t[1]),show=force==null?el.hidden:force;
  if(show&&window.innerWidth<=760){Object.keys(map_).forEach(function(k){if(k!==which){$(map_[k][0]).hidden=true;$(map_[k][1]).setAttribute('aria-expanded','false')}})}
  el.hidden=!show;btn.setAttribute('aria-expanded',String(show));
}
$('#menuBtn').addEventListener('click',function(){togglePanel('layers')});
$('#stormBtn').addEventListener('click',function(){togglePanel('storms')});

function refreshButtons(){
  $$('#layerBtns button').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.layer===S.layer))});
  $$('#baseBtns button').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.base===S.base))});
}
$('#layerBtns').addEventListener('click',function(e){var b=e.target.closest('button');if(b)selectLayer(b.dataset.layer)});
$('#baseBtns').addEventListener('click',function(e){var b=e.target.closest('button');if(b){setBase(b.dataset.base);applyOverlays()}});
$('#regionBtns').addEventListener('click',function(e){
  var b=e.target.closest('button');if(!b)return;
  map.flyToBounds(REGIONS[b.dataset.r],{duration:1.2});
});
$$('[data-ov]').forEach(function(c){c.addEventListener('change',function(){S.ov[c.dataset.ov]=c.checked;save();applyOverlays()})});
$('#opac').addEventListener('input',function(){
  S.opacity=(+this.value)/100;save();
  if(FLD.on)renderField();else if(TL.show&&TL.frames.length)TL.show(TL.idx);
});
$('#uWind').addEventListener('change',function(){S.wind=this.value;save();if(FLD.on)renderField()});
$('#uTemp').addEventListener('change',function(){S.temp=this.value;save();if(FLD.on)renderField()});
$('#uTz').addEventListener('change',function(){S.tz=this.value;save();renderTL()});
$('#srcNote').innerHTML='Data: NASA GIBS (Himawari, VIIRS) · RainViewer · Open-Meteo · GDACS · Esri / OpenStreetMap / CARTO basemaps. Part of the Cyclone Watch project.';

/* keyboard */
document.addEventListener('keydown',function(e){
  if(/input|select|textarea/i.test((e.target.tagName||'')))return;
  if(e.key===' '){e.preventDefault();TL.timer?stopPlay():startPlay()}
  else if(e.key==='ArrowRight'){stopPlay();go(TL.idx+1)}
  else if(e.key==='ArrowLeft'){stopPlay();go(TL.idx-1)}
});

/* permalink */
map.on('moveend',function(){
  try{var c=map.getCenter();history.replaceState(null,'','#'+c.lat.toFixed(2)+','+c.lng.toFixed(2)+','+map.getZoom()+','+S.layer)}catch(e){}
});

/* ============================================================
   START
   ============================================================ */
(function init(){
  $('#opac').value=Math.round(S.opacity*100);
  $('#uWind').value=S.wind;$('#uTemp').value=S.temp;$('#uTz').value=S.tz;
  var h=(location.hash||'').replace('#','').split(',');
  if(h.length>=3&&!isNaN(+h[0])&&!isNaN(+h[1])&&!isNaN(+h[2])){map.setView([+h[0],+h[1]],clamp(+h[2],3,12))}
  if(h[3]&&LAYERS[h[3]])S.layer=h[3];
  if(window.innerWidth>760){togglePanel('storms',true)}
  setBase(S.base);
  buildWatch();buildPast();buildCities();buildModel();applyOverlays();
  renderStormList();
  selectLayer(S.layer);
  loadLiveStorms().then(function(){buildLive();renderStormList();applyOverlays()});
})();

})();
